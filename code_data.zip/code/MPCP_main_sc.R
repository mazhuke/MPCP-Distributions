setwd("C:\\Users\\aaaa\\Desktop\\xunuo")
rm(list=ls())
source("MPCP_fun_sc.R")
#k <- 1
L <- 2
############################### Montecarlo
M <- 500 #Montecarlo replications
N <-500  #sample size
d=2#dimensional of y
m=2 #dimensional of X
#MPCP parameters
beta_0=c(1,-2,1,-2)#lambda
nu_0=c(-1,-3,-3,-1)
theta_0 = c(nu_0,beta_0) #psi=(lambda,nu1)

mpcp_theta=matrix(0,(d*L+d*m),M)
mpcp_std1=matrix(0,(d*L+d*m),M)
mpcp_std2=mpcp_std1;mpcp_std3=mpcp_std1
time1 <- Sys.time()

for(i in 1:M){
  print(paste(i,"th Montecarlo at:",Sys.time()))
  ## Sample
  exp_Sample <- MPCP_sc(nu_0,beta_0, L,N,d)
  y=exp_Sample$data
  X=exp_Sample$X
  # PCP
  init=theta_0+runif(length(theta_0),-0.01,0.01)
  mpcp_fit <- optim(par = init, fn=mpcp_Lik_sc, 
                    method="BFGS",hessian = TRUE,
                    data=y,covariate=X,L=L,N=N,d=d)
  mpcp_lik <- -mpcp_fit$value
  # pcp_fit <- optim(par = theta_0, fn=pcp_Lik, gr=pcp_grad, method="L-BFGS-B")
  #if(any(mpcp_fit$par>5)){
  #print("estimates remove")
  #i=i-1;
  # next
  #}else{ 
  mpcp_theta[,i] <- mpcp_fit$par 
  #}
  #mpcp_theta[,3]>5
  
  H <- mpcp_fit$hessian
  
  mpcp_Sigma2 <- ginv(H)*N
  
  
  #pcp_bias <- pcp_theta-theta_0
  
  
  solve_I<- try(MPCP_Fisher_sc(mpcp_theta[,i],y,X,L,N,d),silent=T)      #cancle 
  if(('NaN' %in% solve_I)){ 
    print("try error in Fisher")
    i=i-1;
    next
  }else{ 
    mpcp_I =solve_I
    
  }
  
  
  
  mpcp_Sigma1 <- ginv(mpcp_I)
  
  mpcp_Sigma3 <-(mpcp_Sigma2)%*%(mpcp_I)%*%(mpcp_Sigma2)
  
  mpcp_std1[,i]<- sqrt(diag(mpcp_Sigma1)/N)
  mpcp_std2[,i]<- sqrt(diag(mpcp_Sigma2)/N)
  mpcp_std3[,i]<- sqrt(diag(mpcp_Sigma3)/N)
  
  #mpcp_std[,i]<- sqrt(diag(mpcp_Sigma)/N)
  
}

time2 <- Sys.time()
print(time2-time1)


round(rowMeans(mpcp_theta)-theta_0,4)
round(apply(mpcp_theta,1,sd),4)
round(rowMeans(mpcp_std1),4)
round(rowMeans(mpcp_std2),4)
round(rowMeans(mpcp_std3),4)