################## PCP distribution function###############################
######################require packages
package_list <- c("Rcpp", "numDeriv", "gtools","pscl","tidyverse")

# 
for (package_name in package_list) {
  if (!require(package_name, character.only = TRUE)) {
    install.packages(package_name)
    library(package_name, character.only = TRUE)
  }
}


library(broom)            # conclude statistical modelling results
library(COMPoissonReg)    # CMP
library(dplyr)            # dataframe processing
library(ggplot2)          # plot
library(gtools)
library(modelr)
library(MASS)             # glm.nb
library(numDeriv)         # grad
library(pscl)             # zeroinfl
library(progress)         # progress bar
library(Rcpp)             # use c++ in R
library(readxl)
library(sandwich) 
library(tidyverse)
library(foreach)          # parallel
library(doParallel)
##################Poisson-Charlier polynomials (2.3)
##(x)n is the falling factorial
falling <- function(x,n){
  return(choose(x,n)*factorial(n))
}   

##(2.3)
PCP <- function(n,k,lambda){
 
  sum1=0
  for (i in 0:n) {
    sum1 <-sum1+ choose(n,i)*(-1)^(n-i)*lambda^(-i)*falling(k,i)
  }
  return(sum1) ###
}  
############PCP probability mass function (2.5)
PCP_sum<-function(k,lambda,nu,L){
  #k=0
  sum2=0
  nu_n=c(1,nu)
  for(n in 0:L){
    sum2=sum2+nu_n[n+1]*PCP(n,k,lambda)
  }
  return(sum2)
}
#dn(lambda)
dn <- function(L,lambda){
  if (L == 0) {
    result <- 1
  } else {
    result <- rep(0, (L+1))
    for (n in 0:L) {
      result[n+1] <- factorial(n)*lambda^(-n)
    }
  }
  return(sqrt(result)) #c(d0(lambda),...,dL(lambda))
}
#(2.5)
PCP_pmf<-function(k,lambda,nu,L){
  #k=0
  pk =  dpois(k,lambda)
  nu_n = c(1,nu)
  u=nu_n*dn(L,lambda)
  qk=pk*PCP_sum(k,lambda,nu,L)^2/c(t(u)%*%(u))
  return(qk)
}
######################loglikehoood function (2.11)
pcp_Lik <- function(theta,data,L,N){
  y=data
  
  nu = theta[1:L]
  lambda=theta[(L+1)]
  
  ell=rep(0,N)
  for(j in 1:N){
    ell[j]=PCP_pmf(y[j],lambda,nu,L)
  }
  return(-sum(log(ell)))
}   # vector data, scalar lambda, vector nu(length=L)
################The first estimator is to estimate matrix Sigma
##d(lj)/d(nu)
Lik_dnu<-function(yj,theta,L){
  #theta=theta_0;yj=y[1]
  nu = theta[1:L]
  lambda=theta[(L+1)]
  nu_n = c(1,nu)
  u=nu_n*dn(L,lambda)
  dnu=rep(0,L)
  for(i in 1:L){
    #i=1
    dnu[i]=-2*factorial(i)*nu[i]*lambda^(-i)/c(t(u)%*%(u))+
      2*PCP(i,yj,lambda)/PCP_sum(yj,lambda,nu,L)
  }
  return(dnu)#c(dnu1,..,dnuL)
}
##d(lj)/d(lambda)
Lik_dlambda<-function(yj,theta,L){
  #yj=y[1]
  nu = theta[1:L]
  lambda=theta[(L+1)]
  nu_n = c(1,nu)
  
  u=nu_n*dn(L,lambda)
  s1=0;s2=0
  for(n in 1:L){
    s1=s1+factorial(n)*n*nu[n]^2*lambda^(-n-1);
    s2=s2+n*nu[n]*PCP(n-1,yj-1,lambda);
  }
 
  dlambda= yj/lambda-1+s1/c(t(u)%*%(u))-
    (2*yj*s2)/(lambda^2*PCP_sum(yj,lambda,nu,L))
  return(dlambda)
}

##d(lj)/d(psi)
Lik_dpsi<-function(yj,theta,L){
  return(c(Lik_dnu(yj,theta,L),Lik_dlambda(yj,theta,L)))
}
######The first estimator is to estimate matrix Σ
PCP_Fisher<-function(theta,data,L,N){
  nu = theta[1:L]
  lambda=theta[(L+1)]
  y=data
  
  I1=matrix(0,(L+1),(L+1))
  for(j in 1:N){
    I1=I1+Lik_dpsi(y[j],theta,L)%*%t(Lik_dpsi(y[j],theta,L))
  }
  return(I1/N)
}
######################DGP: data generate process
PCP_data<- function(nu,lambda,L,N){
  y0 <- rep(0, N)
  #nu=nu_0;lambda=lam_0
  for (i in 1:N) {
    u <- runif(1)
    a <- 0
    f <- PCP_pmf(a,lambda,nu,L)
    while (u >= f) {
      a <- a + 1
      f <- f + PCP_pmf(a,lambda,nu,L)
    }
    y0[i] <- a
  }
  return(y0)
}

