
For plotting files: plotcode.R corresponds to Figure 1, and scplot.R corresponds to Figure 2.

##################################################################################################################################################################
MPCP_main.R is the main program file for the simulation results in Section 4.1, and the function file it calls is MPCP_fun.R. 

Similarly, MPCP_main_sc.R and MPCP_main_exp.R are the main program files for the simulation results in Section 4.2, which serve as the main program files for the E-MPCP and S-MPCP regression models, respectively. The function files they call are MPCP_fun_sc.R and MPCP_fun_exp.R. Meanwhile, PCP_ and other related R files are for the univariate case.



##################################################################################################################################################################
The "real1code" file corresponds to the results in the section Application 1: Hospitalization and its Relationship with Air Pollution. In this file, main.R serves as the main program code, the rest are the required custom function files to be called, pollutants_and_hosp.csv is the raw data file, and main.RData is the saved workspace.


The "real2code" file corresponds to the results in the section Application 2: Mental Health and its Relationship with Digital Habits. Within this file:main-L=2.R and main2-L=2-nu21=0.R serve as the main program codes, respectively for the scenario where L=2 and the scenario where insignificant coefficients are removed.The remaining files are the required custom function files to be called.digital_habits_vs_mental_health.csv is the raw data file. MPCP_sc_nu21=0.RData is the saved workspace of main2-L=2-nu21=0.R.

##################################################################################################################################################################
Section		                   Main Program File(s)       DGP	              Called Custom Function File(s)	      Workspace File(s)
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Simulations	Section 4.1         MPCP_main.R	           3，4，5，6   	                        MPCP_fun.R	                    simulation_work
 
Simulations	Section 4.2         MPCP_main_sc.R	   11，12，13，14	                        MPCP_fun_sc.R	                    simulation_work

Simulations	Section 4.2         MPCP_main_exp.R        7，8，9，10	                        MPCP_fun_exp.R	                    simulation_work

Simulations	Univariate Scenario  PCP_ related R files   1，2		                                                            simulation_work

Empirical Studies  Application 1    main.R              pollutants_and_hosp.csv              Other custom function files               main.RData
                                                             (raw data);                   (included in the "real1code" folder)     (saved workspace)

Empirical Studies  Application 2    main-L=2.R;        digital_habits_vs_mental_health.csv  Other custom function files               MPCP_sc_nu21=0.RData 
                                    main2-L=2-nu21=0.R              (raw data);            (included in the "real2code" folder)     (saved workspace when nu_21=0)
------------------------------------------------------------------------------------------------------------------------------------------------------------------



