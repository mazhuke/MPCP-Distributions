# 单变量GPD的概率质量函数（PMF）

#install.packages(c("nleqslv", "MASS"))
library(nleqslv)  # 求解非线性方程（cₜ依赖的sₜ）
library(MASS) 
gpd_pmf <- function(y, theta, alpha) {
  # 输入：y（观测值，非负整数）、theta（速率参数>0）、alpha（离散度参数）
  # 输出：对应y的GPD概率值（确保非负）
  
  # 约束1：theta必须为正
  if (theta <= 0) return(0)
  # 约束2：确保1+alpha*y > 0（否则概率无意义）
  if (1 + alpha * y <= 0) return(0)
  
  # 处理y=0的特殊情况：(1+alpha*0)^(0-1) = 1（文档隐含定义）
  if (y == 0) {
    term <- 1  # (1+alpha*0)^(0-1) = 1
  } else {
    term <- (1 + alpha * y)^(y - 1)
  }
  
  # 计算GPD概率
  pmf <- (theta^y) * term * exp(-theta * (1 + alpha * y)) / factorial(y)
  # 确保概率非负（数值误差修正）
  max(pmf, 0)
}

# 求解c_t = E(exp(-Y_t))
compute_c_t <- function(theta, alpha) {
  # 输入：theta（GPD速率参数）、alpha（GPD离散度参数）
  # 输出：c_t的值（若求解失败返回NA）
  
  # 定义s_t满足的非线性方程：f(s) = ln(s) - alpha*theta*(s-1) + 1 = 0
  f <- function(s,theta,alpha) {
    log(s) - alpha * theta * (s - 1) + 1
  }
  
  # 求解s_t：初始值设为0.5（s>0，方程通常有唯一正解）
  tryCatch({
    sol <- nleqslv(x = 0.3, fn = f, method = "Broyden",theta=theta,alpha=alpha)
    if (sol$termcd != 1) stop("s_t求解未收敛")  # 检查收敛性
    s_t <- sol$x
    c_t <- exp(theta * (s_t - 1))  # 计算c_t
    c_t
  }, error = function(e) {
    NA  # 求解失败返回NA（后续似然函数设为-∞）
  })
}

# 求解c_tt = E(Y_t * exp(-Y_t))
compute_c_tt <- function(theta, alpha) {
  # 输入：theta（GPD速率参数）、alpha（GPD离散度参数）
  # 输出：c_tt的值（若求解失败返回NA）
  #theta=theta1;alpha=alpha1
  # 先求解s_t（依赖compute_c_t的中间结果，避免重复计算）
  f <- function(s,theta,alpha) {
    log(s) - alpha * theta * (s - 1) + 1
  }
  
  tryCatch({
    sol <- nleqslv(x = 0.3, fn = f, method = "Broyden",theta=theta,alpha=alpha)
    if (sol$termcd != 1) stop("s_t求解未收敛")
    s_t <- sol$x
    
    # 计算c_tt（文档Equation 5）
    denominator <- 1 - alpha * theta * s_t
    if (denominator <= 0) stop("c_tt分母非正")  # 确保分母有效
    exponent <- theta * (1 + alpha) * (s_t - 1) - 1
    c_tt <- theta * (1 / denominator) * exp(exponent)
    c_tt
  }, error = function(e) {
    NA
  })
}


# BGPD的对数似然函数（负对数似然，用于优化最小化）
bgpd_neg_loglik <- function(params, data) {
  # 输入：params（参数向量：theta1, theta2, alpha1, alpha2, lambda）、data（n×2数据框，列名为y1,y2）
  # 输出：负对数似然值（若参数无效返回极大值）
  #params= init_params
  # 拆解参数
  theta1 <- params[1]
  theta2 <- params[2]
  alpha1 <- params[3]
  alpha2 <- params[4]
  lambda <- params[5]
  
  # 提取数据
  y1 <- data[1,]
  y2 <- data[2,]
  n <- dim(data)[2]
  
  # 步骤1：检查参数有效性（基础约束）
  if (any(c(theta1, theta2) <= 1e-6)) return(1e18)  # theta需>0（避免数值问题设下界1e-6）
  
  # 步骤2：求解c1, c2, c11, c22（若求解失败返回极大值）
  c1 <- compute_c_t(theta1, alpha1)
  c2 <- compute_c_t(theta2, alpha2)
  c11 <- compute_c_tt(theta1, alpha1)
  c22 <- compute_c_tt(theta2, alpha2)
  if (any(is.na(c(c1, c2, c11, c22)))) return(1e18)
  
  # 步骤3：计算每个观测的对数似然
  loglik <- 0
  for (i in 1:n) {
    yi1 <- y1[i]
    yi2 <- y2[i]
    
    # 3.1 计算边际GPD的对数似然（单变量GPD的log(PMF)）
    pmf1 <- gpd_pmf(yi1, theta1, alpha1)
    pmf2 <- gpd_pmf(yi2, theta2, alpha2)
    if (any(c(pmf1, pmf2) <= 0)) return(1e18)  # 概率非正则似然无效
    loglik_marginal <- log(pmf1) + log(pmf2)
    
    # 3.2 计算λ修正项的对数：log(1 + λ*(e^{-y1}-c1)*(e^{-y2}-c2))
    term1 <- exp(-yi1) - c1
    term2 <- exp(-yi2) - c2
    correction <- 1 + lambda * term1 * term2
    if (correction <= 0) return(1e18)  # 确保修正项非负（概率非负）
    loglik_correction <- log(correction)
    
    # 3.3 累加单个观测的对数似然
    loglik <- loglik + loglik_marginal + loglik_correction
  }
  
  # 返回负对数似然（优化函数默认最小化）
  -loglik
}

bgpd_mle <- function(data) {
  # 输入：data（n×2数据框，列名为y1,y2，观测值为非负整数）
  # 输出：MLE结果列表（参数估计、对数似然值、收敛状态）
  #data=data_BGP
  # 步骤1：计算矩估计作为初始值
  # 样本统计量
  y1 <- data[1,]
  y2 <- data[2,]
  mean1 <- mean(y1)
  mean2 <- mean(y2)
  var1 <- var(y1)
  var2 <- var(y2)
  
  
  init_params <-c(2,2,1,1,0)
  # 步骤2：设置参数上下界（基于文档约束）
  # 约束：theta>0，alpha_t ∈ (max(-1/theta_t, -m_t^{-1}), 1/theta_t)，lambda范围先设为[-10,10]
  # 注：m_t取数据中y的最大值+1（确保1+alpha_t*m_t>0）
  
  
  # 步骤3：优化负对数似然（L-BFGS-B算法支持上下界）
  optim_result <- optim(
    par = init_params,
    fn = bgpd_neg_loglik,
    data = data,
    #method = "BFGS",
    #lower = lower,
    #upper = upper,
   # control = list(maxit = 1000, reltol = 1e-8)  # 优化控制：最大迭代次数、精度
  )
  
  # 步骤4：整理结果
  # 提取参数估计
  mle_params <- optim_result$par
  names(mle_params) <- c("theta1", "theta2", "alpha1", "alpha2", "lambda")
  
  # 计算对数似然值（负优化结果）
  loglik <- -optim_result$value
  
  
  # 返回结果列表
  list(
    params = mle_params,
    loglik = loglik
  )
}
