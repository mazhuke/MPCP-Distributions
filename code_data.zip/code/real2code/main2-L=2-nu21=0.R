###########digital-diet-healthy#################
###https://www.kaggle.com/datasets/khushikyad001/impact-of-screen-time-on-mental-health
#x1:daily_screen_time_hours
#x2:sleep_quality
#x3:physical_activity_hours_per_week
#x4:log(caffeine_intake_mg_per_day)
#x5:eats_healthy
#x6:mindfulness_minutes_per_day
######
#y1:mood_rating
#y2:stress_level
#y3:weekly_anxiety_score
#y4:weekly_depression_score
###################################################
#read data
setwd("/Users/xunuo/Desktop/多元回归(模拟)/MPCP_main/code_main/real2")
all_data=read.csv("digital_habits_vs_mental_health.csv")

#response
set.seed(123)  # 设置随机数种子，保证结果可复现
index <- sample(x = 1:100000, size = 10000, replace = FALSE)
y1=all_data$stress_level[index]
y2=all_data$mood_score[index]
#covariate
x1=all_data$hours_on_TikTok[index]
x2=all_data$sleep_hours[index]
x3=all_data$social_media_platforms_used[index]

##############without covariate#######
source("MPCP_fun.R")
N=length(y1)
d=2
L=2

y=rbind(y1,y2)

mean(y1);var(y1)
mean(y2);var(y2)

freq_table <- table(y1)
barplot(freq_table, 
        main = "序列取值频数分布", 
        xlab = "取值", 
        ylab = "频数",
        col = "skyblue",  # 柱子颜色
        border = NA)
freq_table <- table(y2*10)
barplot(freq_table, 
        main = "序列取值频数分布", 
        xlab = "取值", 
        ylab = "频数",
        col = "skyblue",  # 柱子颜色
        border = NA)



theta_00 = c(rep(1,d*L),1,1)

mpcp_fit <- optim(par = theta_00, fn=mpcp_Lik, 
                  method="BFGS",hessian = TRUE,
                  data=y,L=L,N=N,d=d)
mpcp_lik <- mpcp_fit$value
mpcp_theta <- mpcp_fit$par 
H <- mpcp_fit$hessian

mpcp_Sigma2 <- ginv(H)*N
solve_I<- try(MPCP_Fisher(mpcp_theta,y,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I)){ 
  print("try error in Fisher")
  next
}else{ 
  mpcp_I =solve_I
  
}
mpcp_Sigma1 <- solve(mpcp_I)
mpcp_Sigma3 <-(mpcp_Sigma2)%*%(mpcp_I)%*%(mpcp_Sigma2)
mpcp_std<- sqrt(diag(mpcp_Sigma3)/N)


AIC=2*mpcp_lik+2*(d*L+d)
BIC=2*mpcp_lik+(d*L+d)*log(N)
logL=mpcp_lik
round(c(logL,AIC,BIC),4)
t.statistics=round(mpcp_theta/mpcp_std,4)
p=2*(1-pnorm(abs(t.statistics))) 
round(p,4)
out<-rbind(round(mpcp_theta,4),
           round(mpcp_std,4),
           round(t.statistics,4),
           round(p,4))


gamma_L<-function(theta,L,dth){
  #theta=mpcp_theta_sc;x=seq(min(X[,2]),max(X[,2]),0.001)
  #L=2;m=3;dth=2;pth=2
  nu=theta[1:(2*L)]
  lam=theta[(2*L+1):(2*L+2)]
  nui=nu[((dth-1)*L+1):((dth-1)*L+L)]
  lami=lam[dth]
  
  ssum1=2*nui[1]*lami^2+lami*nui[1]^2+4*lami*nui[1]*nui[2]+4*nui[2]^2
  ssum2=lami^2+nui[1]^2*lami+2*nui[2]^2
  R1=ssum1/ssum2
  ssum3=nui[1]^2*lami^2+2*lami^2*nui[2]+4*lami*nui[1]*nui[2]+2*(1+lami)*nui[2]^2
  R2=ssum3/ssum2
  
  return(c(R1,R2))
}
lam=mpcp_theta[(2*L+1):(2*L+2)]
EY1.h=lam[1]+gamma_L(mpcp_theta,L,1)[1]/2
EY2.h=lam[2]+gamma_L(mpcp_theta,L,2)[1]/2
VY1.h=lam[1]+gamma_L(mpcp_theta,L,1)[1]/2-gamma_L(mpcp_theta,L,1)[1]^2/4+gamma_L(mpcp_theta,L,1)[2]
VY2.h=lam[2]+gamma_L(mpcp_theta,L,2)[1]/2-gamma_L(mpcp_theta,L,2)[1]^2/4+gamma_L(mpcp_theta,L,2)[2]
EXY.h=-gamma_L(mpcp_theta,L,1)[1]*gamma_L(mpcp_theta,L,2)[1]/4
corr.h=EXY.h/(sqrt(VY1.h)*sqrt(VY2.h))

################regression model (softplus)

source("MPCP_fun_sc_nu21=0.R")
#covariate

X=cbind(rep(1,N),x1)
m=dim(X)[2]
theta_01 = c(5,3,5,rep(0.1,d*m))
mpcp_fit_sc <- optim(par = theta_01, fn=mpcp_Lik_sc, 
                     method="BFGS",hessian = TRUE,
                     data=y,covariate=X,L=L,N=N,d=d)
mpcp_lik_sc <- mpcp_fit_sc$value
mpcp_theta_sc <- mpcp_fit_sc$par 
#H_sc <- mpcp_fit_sc$hessian
#mpcp_Sigma2_sc <- ginv(H_sc)*N
#pcp_bias <- pcp_theta-theta_0
solve_I_sc<- try(MPCP_Fisher_sc(mpcp_theta_sc,y,X,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I_sc)){ 
  print("try error in Fisher")
}else{ 
  mpcp_I_sc =solve_I_sc
  
}

mpcp_Sigma1_sc <- ginv(mpcp_I_sc)
#mpcp_Sigma3_sc <-(mpcp_Sigma2_sc)%*%(mpcp_I_sc)%*%(mpcp_Sigma2_sc)
mpcp_std_sc<-  sqrt(diag(mpcp_Sigma1_sc)/N)
mpcp_std_sc1<-c(mpcp_std_sc[1:2],mpcp_std_sc[4:8])
#sqrt(diag(mpcp_Sigma3_sc)/N)
AIC_sc=2*mpcp_lik_sc+2*(3+m*d)
BIC_sc=2*mpcp_lik_sc+(3+m*d)*log(N)
logL_sc=mpcp_lik_sc
t.statistics_sc=round(mpcp_theta_sc/mpcp_std_sc1,4)
p_sc=2*(1-pnorm(abs(t.statistics_sc))) 
round(p_sc,4)

sc_out<-rbind(round(mpcp_theta_sc,4),
              round(mpcp_std_sc1,4),
              round(t.statistics_sc,4),
              round(p_sc,4))
round(c(logL_sc,AIC_sc,BIC_sc),4)
################regression model (exp)
source("MPCP_fun_exp.R")
theta_02 = c(5,5,5,5,rep(0.1,d*m))
mpcp_fit_exp <- optim(par = theta_02, fn=mpcp_Lik_exp, 
                      method="BFGS",hessian = TRUE,
                      data=y,covariate=X,L=L,N=N,d=d)
mpcp_lik_exp <- mpcp_fit_exp$value
mpcp_theta_exp <- mpcp_fit_exp$par 
#H_exp <- mpcp_fit_exp$hessian
#mpcp_Sigma2_exp <- ginv(H_exp)*N


#pcp_bias <- pcp_theta-theta_0


solve_I_exp<- try(MPCP_Fisher_exp(mpcp_theta_exp,y,X,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I_exp)){ 
  print("try error in Fisher")
}else{ 
  mpcp_I_exp =solve_I_exp
  
}
mpcp_Sigma1_exp <- ginv(mpcp_I_exp)
#mpcp_Sigma3_exp <-(mpcp_Sigma2_exp)%*%(mpcp_I_exp)%*%(mpcp_Sigma2_exp)
mpcp_std_exp<-  sqrt(diag(mpcp_Sigma1_exp)/N)
#sqrt(diag(mpcp_Sigma3_sc)/N)
AIC_exp=2*mpcp_lik_exp+2*(d*L+m*d)
BIC_exp=2*mpcp_lik_exp+(d*L+m*d)*log(N)
logL_exp=mpcp_lik_exp
t.statistics_exp=round(mpcp_theta_exp/mpcp_std_exp,4)
p_exp=2*(1-pnorm(abs(t.statistics_exp))) 
round(p_exp,4)

exp_out<-rbind(round(mpcp_theta_exp,4),
               round(mpcp_std_exp,4),
               round(t.statistics_exp,4),
               round(p_exp,4))
round(c(logL_exp,AIC_exp,BIC_exp),4)
#################camparsion
#BP(lambda1,lambda2,lambda0)
#install.packages("bivpois")
library("bivpois")
MP_fit<-bp.mle(y1,y2)

MP_hat<-MP_fit$lambda
MP_lik <- -MP_fit$loglik[1]
AIC_mp=2*MP_lik+2*(3)
BIC_mp=2*MP_lik+(3)*log(N)
#NB(lambda1,lambda2,phi)
source("MNB_fun.R")
init_mnb=c(5,5,1)
MNB_fit <- optim(par = init_mnb, fn=mnb_Lik,
                 #method="L-BFGS-B", hessian = TRUE,
                 #lower=c(1,1,0.01),upper=c(10,10,9),
                 data=y)

MNB_hat<-MNB_fit$par
MNB_lik <- MNB_fit$value
AIC_mnb=2*MNB_lik+2*(3)
BIC_mnb=2*MNB_lik+(3)*log(N)
round(c(MNB_lik,AIC_mnb,BIC_mnb),4)
#BCP
source("BCP_fun.R")
init_bcp=c(1,1,0)
BCP_fit <- optim(par = init_bcp, fn=bcp_Lik,
                 #method="SANN", hessian = TRUE,
                 data=y)
BCP_hat<-BCP_fit$par
BCP_lik <- BCP_fit$value
AIC_bcp=2*BCP_lik+2*(3)
BIC_bcp=2*BCP_lik+(3)*log(N)
round(c(BCP_lik,AIC_bcp,BIC_bcp),4)
source("BGP_fun.R")
BGP_fit <- bgpd_mle(y)

BGP_hat<-BGP_fit$params
BGP_lik <- BGP_fit$loglik
AIC_bgp=-2*BGP_lik+2*(length(BGP_hat))
BIC_bgp=2*BGP_lik+length(BGP_hat)*log(N)
#BCMP
#install.packages("multicmp")
library(multicmp)
BCMP_fit<-multicmpests(t(y), max = 100, startvalues = NULL)
BCMP_hat<-BCMP_fit$par
BCMP_lik <- BCMP_fit$negll
AIC_bcmp=2*BCMP_lik+2*length(BCMP_hat)
BIC_bcmp=2*BCMP_lik+length(BCMP_hat)*log(N)
#BGeo
library(BCD)
BGeo_fit <- MLEgeomBCD(t(y), initial_values = c(0.5, 0.5, 0.5))

BGeo_hat<-c(BGeo_fit$q1,BGeo_fit$q2,BGeo_fit$q3)
BGeo_lik <- BGeo_fit$logLik
AIC_bgeo=BGeo_fit$AIC
BIC_bgeo=BGeo_fit$BIC


#BP_exp(lambda1t,lambda2t,lambda0)
source("MP_exp_1.R")
init_mp_exp=c(rep(0.1,d*L+d*m))
MP_fit_exp <- optim(par = init_mp_exp, fn=pois_Lik_exp,
                    #method="BFGS", hessian = TRUE,
                    data=y,X=X)
MP_hat_exp<-MP_fit_exp$par
MP_lik_exp <- MP_fit_exp$value
AIC_mp_exp=2*MP_lik_exp+2*length(MP_hat_exp)
BIC_mp_exp=2*MP_lik_exp+length(MP_hat_exp)*log(N)

source("MP_sc_1.R")
init_mp_sc=c(1,0.1,0.1,0.1,0.1,0.1,0.1,
             1,0.1,0.1,0.1,0.1,0.1,0.1,0.1)
MP_fit_sc <- optim(par = init_mp_sc, fn=pois_Lik_sc,
                   #method="BFGS", hessian = TRUE,
                   data=y,X=X)
MP_hat_sc<-MP_fit_sc$par
MP_lik_sc <- MP_fit_sc$value
AIC_mp_sc=2*MP_lik_sc+2*length(MP_hat_sc)
BIC_mp_sc=2*MP_lik_sc+length(MP_hat_sc)*log(N)


source("BCP_exp.R")
init_bcp_exp=c(rep(0.05,2*m),0)
BCP_fit_exp <- optim(par = init_bcp_exp, fn=bcp_Lik_exp,
                     #method="BFGS", hessian = TRUE,
                     data=y,Z=X)
BCP_hat_exp<-BCP_fit_exp$par
BCP_lik_exp <- BCP_fit_exp$value
AIC_bcp_exp=2*BCP_lik_exp+2*length(BCP_hat_exp)
BIC_bcp_exp=2*BCP_lik_exp+length(BCP_hat_exp)*log(N)

source("BCP_sc.R")
init_bcp_sc=c(rep(0.5,2*m),0)
BCP_fit_sc <- optim(par = init_bcp_sc, fn=bcp_Lik_sc,
                    #method="BFGS", hessian = TRUE,
                    data=y,Z=X)
BCP_hat_sc<-BCP_fit_sc$par
BCP_lik_sc <- BCP_fit_sc$value
AIC_bcp_sc=2*BCP_lik_sc+2*length(BCP_hat_sc)
BIC_bcp_sc=2*BCP_lik_sc+length(BCP_hat_sc)*log(N)


source("MNB_exp.R")
init_mnb_exp=c(rep(0.1,2*m),0.1)
MNB_fit_exp <- optim(par = init_mnb_exp, fn=mnb_Lik_exp,
                     #method="BFGS", hessian = TRUE,
                     data=y,X=X)
MNB_hat_exp<-MNB_fit_exp$par
MNB_lik_exp <- MNB_fit_exp$value
AIC_mnb_exp=2*MNB_lik_exp+2*length(MNB_hat_exp)
BIC_mnb_exp=2*MNB_lik_exp+length(MNB_hat_exp)*log(N)


source("MNB_sc.R")
init_mnb_sc=c(rep(1,2*m),1)
MNB_fit_sc <- optim(par = init_mnb_sc, fn=mnb_Lik_sc,
                    #method="BFGS", hessian = TRUE,
                    data=y,X=X)
MNB_hat_sc<-MNB_fit_sc$par
MNB_lik_sc <- MNB_fit_sc$value
AIC_mnb_sc=2*MNB_lik_sc+2*length(MNB_hat_sc)
BIC_mnb_sc=2*MNB_lik_sc+length(MNB_hat_sc)*log(N)

source("BGP_sc.R")
BGP_fit_sc <-bgp_sc(Y=y,X=X)
BGP_hat_sc<-BGP_fit_sc$coefficients[,2]
BGP_lik_sc <- BGP_fit_sc$model_info$log_likelihood
AIC_bgp_sc=BGP_fit_sc$model_info$AIC
BIC_bgp_sc=BGP_fit_sc$model_info$BIC

source("BGP_exp.R")
BGP_fit_exp <-bgp_exp(Y=y,X=X)
BGP_hat_exp<-BGP_fit_exp$coefficients[,2]
BGP_lik_exp <- BGP_fit_exp$model_info$log_likelihood
AIC_bgp_exp=BGP_fit_exp$model_info$AIC
BIC_bgp_exp=BGP_fit_exp$model_info$BIC
source("BGeo_sc.R")
init_bgeo_sc=c(rep(1,2*m),0.1)
BGeo_fit_sc <- optim(par = init_bgeo_sc, fn=bgeo_Lik_sc,
                     method="BFGS", hessian = TRUE,
                     data=y,X=X)
BGeo_hat_sc<-BGeo_fit_sc$par
BGeo_lik_sc <- BGeo_fit_sc$value
AIC_bgeo_sc=2*BGeo_lik_sc+2*length(BGeo_hat_sc)
BIC_bgeo_sc=2*BGeo_lik_sc+length(BGeo_hat_sc)*log(N)


plotdata=as.data.frame(t(y))
corr <- cor(plotdata$y1, plotdata$y2)

hist(y1, 
     breaks = seq(min(y1), max(y1), by = 1),  # 设置区间边界（确保每个整数单独成组）
     col = "deepskyblue3",  # 填充色
     border = "white",   # 边框色
     main = "(a)",#expression(paste("Observed data of ",Y[i][1])),
     xlab = expression(Y[i][1]),
     ylab = "Count",
     las = 1)  # y轴标签水平显示
hist(y2, 
     breaks = seq(min(y2), max(y2), by = 1),  # 设置区间边界（确保每个整数单独成组）
     col = "deepskyblue3",  # 填充色
     border = "white",   # 边框色
     main = "(b)",#expression(paste("Observed data of ",Y[i][2])),
     xlab = expression(Y[i][2]),
     ylab = "Count",
     las = 1)  # y轴标签水平显示
plotdata=as.data.frame(t(y))
library(ggplot2)

corr <- cor(plotdata$y1, plotdata$y2)

# 散点图 + 相关系数
ggplot(plotdata, aes(x = y1, y = y2)) +
  geom_point(alpha = 0.5,color="deepskyblue3") +  # 透明度处理重叠点
  # geom_smooth(method = "lm", se = TRUE,color="red") +  # 添加线性回归线
  labs(title ="(c)" ,
       x=expression(Y[i][1]),
       y=expression(Y[i][2]))+
  theme_bw()+
  theme(
    plot.title = element_text(
      hjust = 0.5,  # 标题居中（可选）
      size = 14,    # 标题字体大小
      face = "bold" # 标题加粗（可选）
    )
  )


#########plot
Affect_X<-function(theta,x,L,m,dth,pth){
  #theta=mpcp_theta_sc;x=seq(min(X[,2]),max(X[,2]),0.001)
  #L=2;m=2;dth=2;pth=2
  nu1=theta[1:2];nu2=c(0,theta[3]);nu=c(nu1,nu2)
  beta=theta[4:7]
  nui=nu[((dth-1)*L+1):((dth-1)*L+L)]
  betai=beta[(dth-1)*m+pth]
  lami=Sc(betai*x)
  
  ssum1=2*nui[1]*lami^2+lami*nui[1]^2+4*lami*nui[1]*nui[2]+4*nui[2]^2
  ssum2=lami^2+nui[1]^2*lami+2*nui[2]^2
  g=lami+ssum1/ssum2/d
  
  ssum3=2*lami^2*nui[1]^3+8*lami*nui[1]*nui[2]^2+8*nui[1]*nui[2]^3-lami^2*nui[1]^2-4*lami^2*nui[1]*nui[2]-8*lami*nui[2]^2-2*nui[1]^2*nui[2]^2
  ssum4=(lami^2+nui[1]^2*lami+2*nui[2]^2)^2
  pro1=ssum3/ssum4
  pro2=d_Sc(betai*x)
  dg=(1+pro1/2)*pro2*betai
  return(list(g=g,dg=dg))
}
X11_test=seq(min(X[,2]),max(X[,2]),0.001)
X11_TikTok=Affect_X(mpcp_theta_sc,X11_test,2,2,1,2)
X2.lab=as.character(round(seq(min(X[,2]),max(X[,2]),by=1),3))
par(mfrow = c(1, 2),mar=c(4,5,2,1),
    oma = c(0, 0, 2, 0))  # 外层边距（给总标题留空间，单位：行数）
plot(X11_TikTok$g,type="l",lwd=2,xaxt="n",
     xlab=expression(X[i][2]~("hours on TikTok")),
     ylab=expression(G[1](X[i][2])),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X11_test),by=1000),labels = X2.lab)

#title(expression("(a)"),adj=0)
plot(X11_TikTok$dg,type="l",lwd=2, col = "deepskyblue3",
     xlab=expression(X[i][2]~("hours on TikTok")),xaxt="n",
     ylab=expression(G[1]^"*"~(X[i][2])),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X11_test),by=1000),labels = X2.lab)

#title(expression("(b)"),adj=0)

mtext(
  text = expression(paste("Panel A: the effect of ", X[i][2]," on ", Y[i][1])),  # 总标题文本
  side = 3,  # 位置：顶部（1=下，2=左，3=上，4=右）
  line = 0.0001,  # 距离顶部的行数（配合oma调整）
  outer = TRUE,  # 跨越整个画布（而非单个子图）
  cex = 1.2 # 字体大小
)

X21_test=seq(min(X[,2]),max(X[,2]),0.001)
X21_TikTok=Affect_X(mpcp_theta_sc,X21_test,2,2,2,2)
plot(X21_TikTok$g,type="l",lwd=2,xaxt="n",
     xlab=expression(X[i][2]~("hours on TikTok")),,
     ylab=expression(G[2](X[i][2])),
     #ylim=c(0.5,0.75),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X21_test),by=1000),labels = X2.lab)

#title(expression("(a)"),adj=0)
plot(X21_TikTok$dg,type="l",lwd=2, col = "deepskyblue3",
     xlab=expression(X[i][2]~("hours on TikTok")),xaxt="n",
     ylab=expression(G[2]^"*"~(X[i][2])),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X21_test),by=1000),labels = X2.lab)

#title(expression("(b)"),adj=0)
mtext(
  text = expression(paste("Panel B: the effect of ", X[i][2]," on ", Y[i][2])),  # 总标题文本
  side = 3,  # 位置：顶部（1=下，2=左，3=上，4=右）
  line = 0.0001,  # 距离顶部的行数（配合oma调整）
  outer = TRUE,  # 跨越整个画布（而非单个子图）
  cex = 1.2 # 字体大小
)
