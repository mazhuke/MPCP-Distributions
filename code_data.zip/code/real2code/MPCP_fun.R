################## Multivariate PCP  distribution###############################
######################require packages
library(broom)            # conclude statistical modelling results
library(COMPoissonReg)    # CMP
library(dplyr)            # dataframe processing
library(ggplot2)          # plot
library(gtools)
library(modelr)
library(MASS)             # glm.nb
library(numDeriv)
library(pscl)             # zeroinfl
library(progress)         # progress bar
library(Rcpp)             # use c++ in R
library(readxl)
library(sandwich) 
library(tidyverse)
library(foreach)          # parallel
library(doParallel)
##################Poisson-Charlier polynomials (2.3)
##(x)n is the falling factorial
falling <- function(x,n){
  return(choose(x,n)*factorial(n))
}   

##(2.3)
PCP <- function(n,k,lambda){
  
  sum1=0
  for (i in 0:n) {
    sum1 <-sum1+ choose(n,i)*(-1)^(n-i)*lambda^(-i)*falling(k,i)
  }
  return(sum1) ###
}  
############PCP probability mass function (6.1)
#sum_n^L vjnCn(k,lambda)
PCP_sum<-function(kj,lambda_j,nu_j,L){
  #k=0
  sum2=0
  
  for(n in 0:L){
    sum2=sum2+nu_j[n+1]*PCP(n,kj,lambda_j)
  }
  return(sum2)
}
#dn(lambda)
dn <- function(L,lambda_j){
  if (L == 0) {
    result <- 1
  } else {
    result <- rep(0, L)
    for (n in 1:L) {
      result[n] <- factorial(n)*lambda_j^(-n)
    }
  }
  result1=c(1,result)
  return(sqrt(result1)) #c(d0(lambda),...,dL(lambda))
}
#(6.1)
MPCP_pmf<-function(k,lambda,nu,L){
  #nu:d*L-dimensional
  #k=y[,1];lambda=c(1,1,1);nu=c(1,1,1)
  d=length(k) ##d-dimensional 
  product1=1;sum1=0
  for(j in 1:d){
    pkj =  dpois(k[j],lambda[j])
    product1=product1*pkj 
    nu_j = c(1,nu[((j-1)*L+1):(j*L)]) #L+1-dimensional
    uj=nu_j*dn(L,lambda[j])
    sum1=sum1+PCP_sum(k[j],lambda[j],nu_j,L)^2/c(t(uj)%*%(uj))
  }
  qk=product1*sum1/d
  return(qk)
}
######################loglikehoood function 
mpcp_Lik <- function(theta,data,L,N,d){
  #theta=theta_00
  y=data #d-dimensional*N matrix
  nu = theta[1:(d*L)] #theta:d*L+1
  lambda=theta[(d*L+1):(d*L+d)]
  
  ell=rep(0,N)
  for(t in 1:N){
    if(d==1){
      ell[t]=MPCP_pmf(y[t],lambda,nu,L) 
    }else{
      ell[t]=MPCP_pmf(y[,t],lambda,nu,L)
    }
    
  }
  #ell=ell[ell>0]
  return(-sum(log(ell)))
}   # vector data, scalar lambda, vector nu(length=L)
################The first estimator is to estimate matrix Sigma
Ct<-function(yt,theta,L){
  d=length(yt)
  nu = theta[1:(d*L)] #theta:d*L+1
  lambda=theta[(d*L+1):(d*L+d)] 
  ct=0
  for(j in 1:d){
    #j=2
    nu_j = c(1,nu[((j-1)*L+1):(j*L)]) 
    uj=nu_j*dn(L,lambda[j])
    ct=ct+(PCP_sum(yt[j],lambda[j],nu_j,L))^2/(t(uj)%*%uj)
    #sum1=sum1+PCP_sum(yjt,lambda,nu_j[,j],L)
  }
  return(ct)
}
##d(lj)/d(nu)
Lik_dnu_j<-function(jth,yt,theta,L){
  #theta=theta_0;yt=y[,1];jth=2
  d=length(yt)
  nu = theta[1:(d*L)] #theta:d*L+1
  lambda=theta[(d*L+1):(d*L+d)]
  
  nu_j = c(1,nu[((jth-1)*L+1):(jth*L)]) 
  uj=nu_j*dn(L,lambda[jth])
  dnu_j=rep(0,L)
  for(n in 1:L){
    #n=1
    At1=(-2)*factorial(n)*nu_j[n+1]*lambda[jth]^(-n)*(PCP_sum(yt[jth],lambda[jth],nu_j,L)^2)/((t(uj)%*%uj)^2)
    Bt1=2*PCP(n,yt[jth],lambda[jth])/(t(uj)%*%uj)*(PCP_sum(yt[jth],lambda[jth],nu_j,L))
    dnu_j[n]=(At1+Bt1)/Ct(yt,theta,L)
  }
  
  return(dnu_j)#c(dnu_j1,..,dnu_jL)
}
Lik_dnu<-function(yt,theta,L){
  #yt=y[,1]
  d=length(yt)
  dnu=rep(0,L*d)
  for(j in 1:d){
    #j=2
    dnu[((j-1)*L+1):(j*L)]=Lik_dnu_j(j,yt,theta,L)
  }
  return(dnu)#c((dnu_11,..,dnu_1L),...,(dnu_d1,..,dnu_dL))
}
##d(lj)/d(lambda)
Lik_dlambda<-function(yt,theta,L){
  #theta=theta_0;yt=5
  d=length(yt)
  nu = theta[1:(d*L)] #theta:d*L+1
  lambda=theta[(d*L+1):(d*L+d)] 
  dlambda=rep(0,d)
  for(j in 1:d){
    nu_j = c(1,nu[((j-1)*L+1):(j*L)]) 
    uj=nu_j*dn(L,lambda[j])
    s1=0;s2=0
    for(n in 1:L){
      s1=s1+factorial(n)*n*nu_j[n+1]^2*lambda[j]^(-n-1);
      s2=s2+n*nu_j[n+1]*PCP(n-1,yt[j]-1,lambda[j]);
    }
    A2=s1/((t(uj)%*%(uj))^2)*(PCP_sum(yt[j],lambda[j],nu_j,L)^2)
    B2=-(2*yt[j]*s2)/(lambda[j]^2)*PCP_sum(yt[j],lambda[j],nu_j,L)/(t(uj)%*%(uj))
    dlambda[j]=yt[j]/lambda[j]-1+(A2+B2)/Ct(yt,theta,L)
  }
  return(dlambda)
}

##d(lt)/d(psi)
Lik_dpsi<-function(yt,theta,L){
  #yt=y[,1]
  return(c(Lik_dnu(yt,theta,L),Lik_dlambda(yt,theta,L)))
}#L*d+1-dim
######The first estimator is to estimate matrix Σ
MPCP_Fisher<-function(theta,data,L,N,d){
  y=data #d-dimensional*N matrix
  #d=dim(y)[1]
  I1=matrix(0,(d*L+d),(d*L+d))
  for(t in 1:N){
    if(d==1){
      I1=I1+Lik_dpsi(y[t],theta,L)%*%t(Lik_dpsi(y[t],theta,L)) 
    }else{
      I1=I1+Lik_dpsi(y[,t],theta,L)%*%t(Lik_dpsi(y[,t],theta,L))
    }
    
  }
  return(I1/N)
}
######################DGP: data generate process

##(6.5)
sum_wk<-function(k,lambda_j,nu,L,s){
  #s=1;nu=nu_0;lambda=lam_0 k
  if(s==0){
    wk=0
  }else{
    wk=rep(0,s)
    for(j in 1:s){
      nu_j <- c(1, nu[((j-1)*L + 1):(j*L)])
      uj=nu_j*dn(L,lambda_j)
      wk[j]=PCP_sum(k[j],lambda_j,nu_j,L)^2/c(t(uj)%*%(uj))  
    } 
  }
  return(sum(wk))
}
MPCP_pmfs<-function(ks,k_s,lambda_j,nu,L,d,s){
  #ks=1;k_s=k_st;s=3;nu=nu_0;lambda=lam_0
  pks = dpois(ks,lambda_j)
  if(s==1){
    fs=pks*(sum_wk(ks,lambda_j,nu,L,s)+d-s)/(sum_wk(k_s,lambda_j,nu,L,s-1)+d-s+1)
  }else{
    k=c(k_s,ks)
    fs=pks*(sum_wk(k,lambda_j,nu,L,s)+d-s)/(sum_wk(k_s,lambda_j,nu,L,s-1)+d-s+1)
  }
  
  return(fs)
}


component_sample <- function(k_s,nu,lambda_j,L,N,d,s) {
  #k_s=y0[1:(j-1),];s=3
  yj <- rep(0, N);
  #nu=nu_0;lambda=lam_0
  for (t in 1:N) {
    #t=1
    if(length(dim(k_s))>1){
      k_st=k_s[,t]
    }else{k_st=k_s[t]}
    u <- runif(1)
    a <- 0
    f <- MPCP_pmfs(a,k_st,lambda_j,nu,L,d,s)
    while (u >= f) {
      a <- a + 1
      f <- f + MPCP_pmfs(a,k_st,lambda_j,nu,L,d,s)
    }
    yj[t] <- a
  }
  
  return(yj)
}

MPCP <- function(nu,lambda,L,N,d){
  y0 <- matrix(0,d,N)
  #nu=nu_0;lambda=lam_0
  if(d==1){
    
    y0=component_sample(rep(0,N),nu,lambda,L,N,d,1) 
  }else{
    y0[1,]=component_sample(rep(0,N),nu,lambda[1],L,N,d,1)
    for (j in 2:d) {
      #j=3
      y0[j,] <-component_sample(y0[1:(j-1),],nu,lambda[j],L,N,d,j)
    }
  }
  return(y0)
}
