get_s <- function(phi, mu) {
  # 输入：phi（离散参数）、mu（边际均值）
  # 输出：s_t（方程的根）
  if (mu <= 0) stop("边际均值mu必须为正")
  denom <- 1 + phi * mu
  if (denom <= 0) stop("1+phi*mu必须为正（请调整phi范围）")
  
  # 定义待求解的方程
  equation <- function(s) {
    log(s) + 1 - (phi * mu * (s - 1)) / denom
  }
  
  # 数值求解（区间(0,1)，避免边界值）
  root <- uniroot(equation, interval = c(1e-6, 1 - 1e-6))$root
  return(root)
}

log_likexp <- function(params, Y, X) {
  # 输入：
  #   params: 参数向量（beta1(p个), beta2(p个), phi1, phi2, lambda12）
  #   y1, y2: 二元响应变量（计数数据）
  #   X: 协变量矩阵（含截距，n行p列）
  # 输出：负对数似然值
  y1=Y[1,];y2=Y[2,];
  n <- length(y1)
  p <- ncol(X)
  
  # 1. 拆分参数
  beta1 <- params[1:p]          # y1的回归系数
  beta2 <- params[(p+1):(2*p)]  # y2的回归系数
  phi1 <- params[2*p + 1]       # y1的离散参数
  phi2 <- params[2*p + 2]       # y2的离散参数
  lambda12 <- params[2*p + 3]   # 相关参数
  
  # 2. 计算边际均值mu1, mu2（log(μ) = Xβ）
  mu1 <- exp(X %*% beta1)
  mu2 <- exp(X %*% beta2)
  mu1[mu1 < 1e-6] <- 1e-6  # 避免数值下溢
  mu2[mu2 < 1e-6] <- 1e-6
  
  # 3. 计算c1, c2（E(e^{-Yₜ})，依赖sₜ）
  s1 <- sapply(1:n, function(i) get_s(phi1, mu1[i]))
  s2 <- sapply(1:n, function(i) get_s(phi2, mu2[i]))
  denom1 <- 1 + phi1 * mu1
  denom2 <- 1 + phi2 * mu2
  c1 <- exp(mu1 * (s1 - 1) / denom1)
  c2 <- exp(mu2 * (s2 - 1) / denom2)
  
  # 4. 单变量GPD的对数似然项
  # 4.1 y1的GPD项
  theta1 <- mu1 / denom1  # GPD的尺度参数
  term1_y1 <- y1 * log(theta1)
  term2_y1 <- ifelse(y1 == 0, 0, (y1 - 1) * log(1 + phi1 * y1))  # y=0时(0-1)*log(1)=0
  term3_y1 <- -lfactorial(y1)  # 对数阶乘，避免数值溢出
  term4_y1 <- -theta1 * (1 + phi1 * y1)
  gpd1 <- term1_y1 + term2_y1 + term3_y1 + term4_y1
  
  # 4.2 y2的GPD项（同理）
  theta2 <- mu2 / denom2
  term1_y2 <- y2 * log(theta2)
  term2_y2 <- ifelse(y2 == 0, 0, (y2 - 1) * log(1 + phi2 * y2))
  term3_y2 <- -lfactorial(y2)
  term4_y2 <- -theta2 * (1 + phi2 * y2)
  gpd2 <- term1_y2 + term2_y2 + term3_y2 + term4_y2
  
  # 5. 相关性项（文档公式中的乘积因子对数）
  corr_term <- lambda12 * (exp(-y1) - c1) * (exp(-y2) - c2)
  if (any(1 + corr_term <= 0)) return(-Inf)  # 确保概率非负，否则似然为负无穷
  log_corr <- log(1 + corr_term)
  
  # 6. 总对数似然（返回负值供optim最小化）
  total_ll <- sum(gpd1 + gpd2 + log_corr)
  return(-total_ll)
}

bgp_exp <- function(Y, X) {
  # 输入：
  #   y1, y2: 响应变量（计数数据）
  #   X: 协变量矩阵（含截距，列名需明确）
  #   init_params: 初始参数（默认用单变量泊松回归结果）
  # 输出：拟合结果列表（系数、标准误、模型信息）
  #Y=y;X=X
  # 输入校验
  y1=Y[1,];y2=Y[2,];
  if (length(y1) != length(y2)) stop("y1和y2长度必须一致")
  if (nrow(X) != length(y1)) stop("X的行数必须与y1一致")
  n <- length(y1)
  p <- ncol(X)
  
  
  # 初始参数向量：beta1 + beta2 + phi1=0 + phi2=0 + lambda12=0
  #init_params <- c(beta1_init, beta2_init, 0, 0, 0)
    init_params <- c(1,0.1,1,0.1, 0, 0, 0)
  
  if (length(init_params) != 2*p + 3) stop(paste("初始参数长度应为", 2*p + 3))
  
  # 8. 极大似然优化（L-BFGS-B支持参数约束）
  # 参数约束：phi∈(-0.5, 0.5)（避免1+phi*mu≤0），lambda∈(-10,10)（避免相关性项异常）
  lower_bounds <- c(rep(-Inf, 2*p), 0, 0, -10)
  upper_bounds <- c(rep(Inf, 2*p), 0.5, 0.5, 10)
  
  fit_optim <- optim(
    par = init_params,
    fn = log_likexp,
    Y=Y,
    X = X,
    method = "L-BFGS-B",
    lower = lower_bounds,
    upper = upper_bounds,
    #hessian = TRUE,  # 计算Hessian矩阵（用于标准误）
    control = list(maxit = 1000)  # 优化控制
  )
  
  # 9. 结果整理
 
  # 9.2 参数估计与标准误（协方差矩阵=(-Hessian)^(-1)）
  estimates <- fit_optim$par
  
  
  # 9.3 模型诊断指标（对数似然、AIC）
  log_lik <- -fit_optim$value  # 原始对数似然（负的优化目标值）
  n_params <- length(estimates)
  aic <- 2 * n_params - 2 * log_lik  # AIC公式
  bic <- n_params * log(n) - 2 * log_lik  # BIC公式
  # 9.4 结果表格（参数名、估计值、标准误、Z值、P值）
  param_names <- c(
    paste0("beta1_", colnames(X)),  # y1的回归系数
    paste0("beta2_", colnames(X)),  # y2的回归系数
    "phi1", "phi2", "lambda12"     # 离散与相关参数
  )
  coef_table <- data.frame(
    Parameter = param_names,
    Estimate = round(estimates, 4)
  )
  
  # 10. 返回结果列表
  return(list(
    coefficients = coef_table,
    model_info = list(
      log_likelihood = round(log_lik, 4),
      AIC = round(aic, 4),
      BIC=round(bic,4)
    )
  ))
}
###########################################################################


