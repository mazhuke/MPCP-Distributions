Product1<-function(theta,p){
  lambda=theta[1:p]
  phi=theta[p+1]
  pro1=1
  for(j in 1:p){
    pro1=pro1*(lambda[j]-phi)
  }
  return(pro1)
}

Sum<-function(theta,k){
  p=length(k)
  lambda=theta[1:p]
  phi=theta[p+1]
  sum1=0
  for (i in 0:min(k)){
    pro=1
    for(j in 1:p){
      pro=pro*choose(k[j],i)
    }
    sum1=sum1+pro*factorial(i)*((phi/Product1(theta,p))^i)
  }
  return(sum1)
}

Product2<-function(theta,k){
  p=length(k)
  lambda=theta[1:p]
  phi=theta[p+1]
  pro2=1
  for(j in 1:p){
    pro2=pro2*(lambda[j]-phi)^k[j]/factorial(k[j])
  }
  return(pro2)
}

pois_pmf<-function(theta,k){
  #k=y[,1]
  p=length(k)
  lambda=theta[1:p]
  phi=theta[p+1]
  pmf=exp(-sum(k)+(p-1)*phi)*Product2(theta,k)*Sum(theta,k)
  return(pmf)
}

pois_Lik<-function(theta,data){
  #theta=c(5,5,1)
  y=data
  p=dim(y)[1];
  N=dim(y)[2];
  lambda=theta[1:p]
  phi=theta[p+1]
  ell=rep(0,N)
  for(t in 1:N){
    ell[t]=pois_pmf(theta,y[,t])
  }
  #ell[ell<=0]=1
  return(-sum(log(ell)))
} 

pois_DGP<-function(theta,p,N){
  lambda=theta[1:p]
  phi=theta[p+1]
  X=matrix(0,p,N)->y
  X1=rpois(N,phi)
  for (j in 1:p){
    X[j,]=rpois(N,lambda[j]-phi)
    y[j,]=X[j,]+X1
  }
  return(y)
}


