pois_Lik_exp<-function(theta,data,X){
  #theta=c(1,0.1,0.1,1,0.1,0.1,0.1);data=y
  y=data
  y1=data[1,]
  y2=data[2,]
  m=dim(X)[2]
  beta1=theta[1:(m)];beta2=theta[(m+1):(2*m)]
  phi=theta[2*m+1]
  
  ell=rep(0,N)
  for(t in 1:N){
    #t=1
    lambda1=exp(X[t,]%*%beta1);lambda2=exp(X[t,]%*%beta2)
    library(bivpois)
    ell[t]=dbp(y1[t],y2[t],c(lambda1,lambda2,phi))
  }
  #ell[ell<=0]=1
  return(-sum(ell))
} 
