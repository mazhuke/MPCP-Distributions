
bcp_pmf_exp<-function(theta,k,zj){
  x=k[1];y=k[2];
  m=length(zj)
  beta1=theta[1:m];beta2=theta[(m+1):(2*m)]
  phi=theta[(2*m)+1]
  lambda1j=exp(zj%*%beta1)
  lambda2j=exp(zj%*%beta2)
  a=(lambda1j^x)*(lambda2j^y)/(factorial(x)*factorial(y))
  b=-lambda1j*(1+y*(exp(phi)-1))
  c=-lambda2j*exp(-lambda1j*(exp(phi)-1)+phi*x)
  d=phi*x*y
  pmf=a*exp(b+c+d)
  return(pmf)
}

bcp_Lik_exp<-function(theta,data,Z){
  #theta=theta_0
  y=data
  N=dim(y)[2];
  m=dim(Z)[2]
  ell=rep(0,N)
  for(t in 1:N){
    ell[t]=bcp_pmf_exp(theta,y[,t],Z[t,])
  }
  ell[ell<=0]=1
  return(-sum(log(ell)))
} 

bcp_DGP_exp<-function(theta,m,N){
  #theta=c(2,2,1)
  beta1=theta[1:m];beta2=theta[(m+1):(2*m)]
  phi=theta[(2*m)+1]
  library(MASS)
  X=cbind(rep(1,N),mvrnorm(N,rep(1,m-1),diag(0.25,m-1)))
  lambda1=exp(X%*%beta1)
  lambda2=exp(X%*%beta2)
  Z1=rpois(N,lambda1)
  mu2=lambda2*exp(-lambda1*(exp(phi)-1))
  Z2=rpois(N,mu2*exp(phi*Z1))
  y=rbind(Z1,Z2)
  return(y)
}


