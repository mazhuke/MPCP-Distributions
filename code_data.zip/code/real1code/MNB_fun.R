Product1<-function(theta,k){
  p=length(k)
  lambda=theta[1:p]
  phi=theta[p+1]
  pro1=1
  for(j in 1:p){
    pro1=pro1*(lambda[j]^k[j])
  }
  return(pro1)
}

Product2<-function(theta,k){
  p=length(k)
  lambda=theta[1:p]
  phi=theta[p+1]
  pro2=1
  for(j in 1:p){
    pro2=pro2*gamma(k[j]+1)
  }
  return(pro2)
}

mnb_pmf<-function(theta,k){
  p=length(k)
  lambda=theta[1:p]
  phi=theta[p+1]
  a=gamma(1/phi+sum(k))/(gamma(1/phi)*Product2(theta,k))
  b=Product1(theta,k)*(phi^(-1/phi))
  c=(1/phi+sum(lambda))^(-(1/phi+sum(k)))
  pmf=a*b*c
  return(pmf)
}

mnb_Lik<-function(theta,data){
  #theta=c(3,4,2)
  y=data
  p=dim(y)[1];
  N=dim(y)[2];
  ell=rep(0,N)
  for(t in 1:N){
    ell[t]=mnb_pmf(theta,y[,t])
  }
 
  #ell<-ell[!is.infinite(ell) & ell > 0]
  #ell1=log(ell)
  #loglik=-sum(ell1[!is.na(ell1)])
  loglik=-sum(log(ell))
  return(loglik)
} 

mnb_DGP<-function(theta,p,N){
  lambda=theta[1:p]
  phi=theta[p+1]
  omega=rgamma(1,1/phi,1/phi)
  y=matrix(0,p,N)
  for (j in 1:p){
    y[j,]=rpois(N,omega*lambda[j])
  }
  return(y)
}


