###########pollution-and-hospitalization#################
###https://www.kaggle.com/datasets/pedroberger/pollution-and-hospitalization?select=pollutants_and_hosp.csv
#x1:PM10 Daily average of Particulate Matter 10 in the region
#x2:PM2.5 Daily average of Particulate Matter 2.5 in the region

######
#y1:SIH_GV_J_Old
#y2:SIH_GV_J_Kid

###################################################
#read data
setwd("/Users/xunuo/Desktop/多元回归(模拟)/MPCP_main/code_main/real1/real1code")
all_data=read.csv("pollutants_and_hosp.csv")
x11=all_data$pm25.gv
index=which(!is.na(x11))
#response
y1=all_data$SIH_GV_J_Old[index]
which(is.na(y1))
y2=all_data$SIH_GV_J_Kid[index]
which(is.na(y2))
#covariate
x1=all_data$pm25.gv[index]

which(is.na(x1))
x2=all_data$pm10.gv[index]
which(is.na(x2))
x3=all_data$so2.gv[index]
which(is.na(x3))
x4=all_data$no2.gv[index]
which(is.na(x4))
x5=(all_data$co.gv)[index]
which(is.na(x5))
x6=all_data$o3.gv[index]
which(is.na(x6))


##############without covariate#######
source("MPCP_fun.R")
N=length(y1)
d=2
L=2

y=rbind(y1,y2)

mean(y1);var(y1)
mean(y2);var(y2)

theta_00 = c(rep(1,d*L),2,2) #L=1 c(rep(1,d*L),3,3)

mpcp_fit <- optim(par = theta_00, fn=mpcp_Lik, 
                  method="BFGS",hessian = TRUE,
                  data=y,L=L,N=N,d=d)
mpcp_lik <- mpcp_fit$value
mpcp_theta <- mpcp_fit$par 
H <- mpcp_fit$hessian

mpcp_Sigma2 <- ginv(H)*N
solve_I<- try(MPCP_Fisher(mpcp_theta,y,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I|'try-error' %in% solve_I)){ 
  print("try error in Fisher")
}else{ 
  mpcp_I =solve_I
  
}
mpcp_Sigma1 <- ginv(mpcp_I)
mpcp_Sigma3 <-(mpcp_Sigma2)%*%(mpcp_I)%*%(mpcp_Sigma2)
mpcp_std<- sqrt(diag(mpcp_Sigma3)/N)


AIC=2*mpcp_lik+2*(d*L+d)
BIC=2*mpcp_lik+(d*L+d)*log(N)
logL=mpcp_lik
t.statistics=round(mpcp_theta/mpcp_std,4)
p=2*(1-pnorm(abs(t.statistics))) 
round(p,4)
out<-rbind(round(mpcp_theta,4),
           round(mpcp_std,4),
           round(t.statistics,4),
           round(p,4))

gamma_L<-function(theta,L,dth){
  #theta=mpcp_theta;x=seq(min(X[,2]),max(X[,2]),0.001)
  #L=2;m=3;dth=2;pth=2
  nu=theta[1:(2*L)]
  lam=theta[(2*L+1):(2*L+2)]
  nui=nu[((dth-1)*L+1):((dth-1)*L+L)]
  lami=lam[dth]
  
  ssum1=2*nui[1]*lami^2+lami*nui[1]^2+4*lami*nui[1]*nui[2]+4*nui[2]^2
  ssum2=lami^2+nui[1]^2*lami+2*nui[2]^2
  R1=ssum1/ssum2
  ssum3=nui[1]^2*lami^2+2*lami^2*nui[2]+4*lami*nui[1]*nui[2]+2*(1+lami)*nui[2]^2
  R2=ssum3/ssum2
  
  return(c(R1,R2))
}
lam=mpcp_theta[(2*L+1):(2*L+2)]
EY1.h=lam[1]+gamma_L(mpcp_theta,L,1)[1]/2
EY2.h=lam[2]+gamma_L(mpcp_theta,L,2)[1]/2
VY1.h=lam[1]+gamma_L(mpcp_theta,L,1)[1]/2-gamma_L(mpcp_theta,L,1)[1]^2/4+gamma_L(mpcp_theta,L,1)[2]
VY2.h=lam[2]+gamma_L(mpcp_theta,L,2)[1]/2-gamma_L(mpcp_theta,L,2)[1]^2/4+gamma_L(mpcp_theta,L,2)[2]
EXY.h=-gamma_L(mpcp_theta,L,1)[1]*gamma_L(mpcp_theta,L,2)[1]/4
corr.h=EXY.h/(sqrt(VY1.h)*sqrt(VY2.h))

################regression model (softplus)
source("MPCP_fun_sc.R")
#covariate
#xx1=scale(x1, center = TRUE)
#xx2=scale(x2, center = TRUE)
X=cbind(rep(1,N),x1,x2)
m=dim(X)[2]
theta_01 = c(rep(1,d*L),rep(0.1,d*m))
mpcp_fit_sc <- optim(par = theta_01, fn=mpcp_Lik_sc, 
                     method="BFGS",hessian = TRUE,
                     data=y,covariate=X,L=L,N=N,d=d)
mpcp_lik_sc <- mpcp_fit_sc$value
mpcp_theta_sc <- mpcp_fit_sc$par 
#H_sc <- mpcp_fit_sc$hessian
#mpcp_Sigma2_sc <- ginv(H_sc)*N
#pcp_bias <- pcp_theta-theta_0
solve_I_sc<- try(MPCP_Fisher_sc(mpcp_theta_sc,y,X,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I_sc)){ 
  print("try error in Fisher")
}else{ 
  mpcp_I_sc =solve_I_sc
  
}
library(MASS)
mpcp_Sigma1_sc <- solve(mpcp_I_sc)
#mpcp_Sigma3_sc <-(mpcp_Sigma2_sc)%*%(mpcp_I_sc)%*%(mpcp_Sigma2_sc)
mpcp_std_sc<-  sqrt(diag(mpcp_Sigma1_sc)/N)
#sqrt(diag(mpcp_Sigma3_sc)/N)
AIC_sc=2*mpcp_lik_sc+2*(d*L+m*d)
BIC_sc=2*mpcp_lik_sc+(d*L+m*d)*log(N)
logL_sc=mpcp_lik_sc
t.statistics_sc=round(mpcp_theta_sc/mpcp_std_sc,4)
p_sc=2*(1-pnorm(abs(t.statistics_sc))) 
round(p_sc,4)

sc_out<-rbind(round(mpcp_theta_sc,4),
              round(mpcp_std_sc,4),
              round(t.statistics_sc,4),
              round(p_sc,4))
################regression model (exp)
source("MPCP_fun_exp.R")
theta_02 = c(rep(1,d*L),rep(0.01,d*m))
mpcp_fit_exp <- optim(par = theta_02, fn=mpcp_Lik_exp, 
                      method="BFGS",hessian = TRUE,
                      data=y,covariate=X,L=L,N=N,d=d)
mpcp_lik_exp <- mpcp_fit_exp$value
mpcp_theta_exp <- mpcp_fit_exp$par 
#H_exp <- mpcp_fit_exp$hessian
#mpcp_Sigma2_exp <- ginv(H_exp)*N


#pcp_bias <- pcp_theta-theta_0


solve_I_exp<- try(MPCP_Fisher_exp(mpcp_theta_exp,y,X,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I_exp)){ 
  print("try error in Fisher")
}else{ 
  mpcp_I_exp =solve_I_exp
  
}
mpcp_Sigma1_exp <- ginv(mpcp_I_exp)
#mpcp_Sigma3_exp <-(mpcp_Sigma2_exp)%*%(mpcp_I_exp)%*%(mpcp_Sigma2_exp)
mpcp_std_exp<-  sqrt(diag(mpcp_Sigma1_exp)/N)
#sqrt(diag(mpcp_Sigma3_sc)/N)
AIC_exp=2*mpcp_lik_exp+2*(d*L+m*d)
BIC_exp=2*mpcp_lik_exp+(d*L+m*d)*log(N)
logL_exp=mpcp_lik_exp
t.statistics_exp=round(mpcp_theta_exp/mpcp_std_exp,4)
p_exp=2*(1-pnorm(abs(t.statistics_exp))) 
round(p_exp,4)

exp_out<-rbind(round(mpcp_theta_exp,4),
               round(mpcp_std_exp,4),
               round(t.statistics_exp,4),
               round(p_exp,4))
#################camparsion
#BP(lambda1,lambda2,lambda0)
#install.packages("bivpois")
library("bivpois")
MP_fit<-bp.mle(y1,y2)

MP_hat<-MP_fit$lambda
MP_lik <- MP_fit$loglik[1]
AIC_mp=-2*MP_lik+2*(3)
BIC_mp=-2*MP_lik+(3)*log(N)
#NB(lambda1,lambda2,phi)
source("MNB_fun.R")
init_mnb=c(5,5,0.1)
MNB_fit <- optim(par = init_mnb, fn=mnb_Lik,
                 #method="L-BFGS-B", hessian = TRUE,
                 #lower=c(0.01,0.01,0.5),upper=c(99,99,99),
                 data=y)
MNB_hat<-MNB_fit$par
MNB_lik <- MNB_fit$value
AIC_mnb=2*MNB_lik+2*(3)
BIC_mnb=2*MNB_lik+(3)*log(N)
#BCP
source("BCP_fun.R")
init_bcp=c(2,3,-1)
BCP_fit <- optim(par = init_bcp, fn=bcp_Lik,
                 #method="BFGS", hessian = TRUE,
                 data=y)
BCP_hat<-BCP_fit$par
BCP_lik <- BCP_fit$value
AIC_bcp=2*BCP_lik+2*(3)
BIC_bcp=2*BCP_lik+(3)*log(N)

source("BGP_fun.R")
BGP_fit <- bgpd_mle(y)

BGP_hat<-BGP_fit$params
BGP_lik <- BGP_fit$loglik
AIC_bgp=-2*BGP_lik+2*(length(BGP_hat))
BIC_bgp=2*BGP_lik+length(BGP_hat)*log(N)
#BCMP
#install.packages("multicmp")
library(multicmp)
BCMP_fit<-multicmpests(t(y), max = 100, startvalues = NULL)
BCMP_hat<-BCMP_fit$par
BCMP_lik <- BCMP_fit$negll
AIC_bcmp=2*BCMP_lik+2*length(BCMP_hat)
BIC_bcmp=2*BCMP_lik+length(BCMP_hat)*log(N)
#BGeo

#install.packages("BCD")
library(BCD)
BGeo_fit <- MLEgeomBCD(t(y), initial_values = c(0.5, 0.5, 0.5))

BGeo_hat<-c(BGeo_fit$q1,BGeo_fit$q2,BGeo_fit$q3)
BGeo_lik <- BGeo_fit$logLik
AIC_bgeo=BGeo_fit$AIC
BIC_bgeo=BGeo_fit$BIC


#BP_exp(lambda1t,lambda2t,lambda0)
source("MP_exp.R")
init_mp_exp=c(1,0.1,0.1,1,0.1,0.1,0.1)
MP_fit_exp <- optim(par = init_mp_exp, fn=pois_Lik_exp,
                    #method="BFGS", hessian = TRUE,
                    data=y,X=X)
MP_hat_exp<-MP_fit_exp$par
MP_lik_exp <- MP_fit_exp$value
AIC_mp_exp=2*MP_lik_exp+2*length(MP_hat_exp)
BIC_mp_exp=2*MP_lik_exp+length(MP_hat_exp)*log(N)

source("MP_sc.R")
init_mp_sc=c(1,0.1,0.1,1,0.1,0.1,0.1)
MP_fit_sc <- optim(par = init_mp_sc, fn=pois_Lik_sc,
                   #method="BFGS", hessian = TRUE,
                   data=y,X=X)
MP_hat_sc<-MP_fit_sc$par
MP_lik_sc <- MP_fit_sc$value
AIC_mp_sc=2*MP_lik_sc+2*length(MP_hat_sc)
BIC_mp_sc=2*MP_lik_sc+length(MP_hat_sc)*log(N)


source("BCP_exp.R")
init_bcp_exp=c(1,0.01,0.01,1,0.01,0.01,0.1)
BCP_fit_exp <- optim(par = init_bcp_exp, fn=bcp_Lik_exp,
                     #method="BFGS", hessian = TRUE,
                     data=y,Z=X)
BCP_hat_exp<-BCP_fit_exp$par
BCP_lik_exp <- BCP_fit_exp$value
AIC_bcp_exp=2*BCP_lik_exp+2*length(BCP_hat_exp)
BIC_bcp_exp=2*BCP_lik_exp+length(BCP_hat_exp)*log(N)

source("BCP_sc.R")
init_bcp_sc=c(1,0.1,0.1,1,0.1,0.1,0.1)
BCP_fit_sc <- optim(par = init_bcp_sc, fn=bcp_Lik_sc,
                    #method="BFGS", hessian = TRUE,
                    data=y,Z=X)
BCP_hat_sc<-BCP_fit_sc$par
BCP_lik_sc <- BCP_fit_sc$value
AIC_bcp_sc=2*BCP_lik_sc+2*length(BCP_hat_sc)
BIC_bcp_sc=2*BCP_lik_sc+length(BCP_hat_sc)*log(N)


source("MNB_exp.R")
init_mnb_exp=c(1,0.1,0.1,1,0.1,0.1,0.1)
MNB_fit_exp <- optim(par = init_mnb_exp, fn=mnb_Lik_exp,
                     #method="BFGS", hessian = TRUE,
                     data=y,X=X)
MNB_hat_exp<-MNB_fit_exp$par
MNB_lik_exp <- MNB_fit_exp$value
AIC_mnb_exp=2*MNB_lik_exp+2*length(MNB_hat_exp)
BIC_mnb_exp=2*MNB_lik_exp+length(MNB_hat_exp)*log(N)


source("MNB_sc.R")
init_mnb_sc=c(1,0.5,0.5,1,0.5,0.5,0.1)
MNB_fit_sc <- optim(par = init_mnb_sc, fn=mnb_Lik_sc,
                    #method="BFGS", hessian = TRUE,
                    data=y,X=X)
MNB_hat_sc<-MNB_fit_sc$par
MNB_lik_sc <- MNB_fit_sc$value
AIC_mnb_sc=2*MNB_lik_sc+2*length(MNB_hat_sc)
BIC_mnb_sc=2*MNB_lik_sc+length(MNB_hat_sc)*log(N)

source("BGP_sc.R")
BGP_fit_sc <-bgp_sc(Y=y,X=X)
BGP_hat_sc<-BGP_fit_sc$coefficients
BGP_lik_sc <- BGP_fit_sc$model_info$log_likelihood
AIC_bgp_sc=BGP_fit_sc$model_info$AIC
BIC_bgp_sc=BGP_fit_sc$model_info$BIC

source("BGP_exp.R")
BGP_fit_exp <-bgp_exp(Y=y,X=X)
BGP_hat_exp<-BGP_fit_exp$coefficients
BGP_lik_exp <- BGP_fit_exp$model_info$log_likelihood
AIC_bgp_exp=BGP_fit_exp$model_info$AIC
BIC_bgp_exp=BGP_fit_exp$model_info$BIC
###############################plot 

hist(y1, 
     breaks = seq(min(y1), max(y1), by = 1),  # 
     col = "deepskyblue3",  # 
     border = "white",   # 
     main = "(a)",#expression(paste("Observed data of ",Y[i][1])),
     xlab = expression(Y[i][1]),
     ylab = "Count",
     las = 1)  # 
hist(y2, 
     breaks = seq(min(y2), max(y2), by = 1),  #
     col = "deepskyblue3",  #
     border = "white",   # 
     main = "(b)",#expression(paste("Observed data of ",Y[i][2])),
     xlab = expression(Y[i][2]),
     ylab = "Count",
     las = 1)  # 
plotdata=as.data.frame(t(y))
library(ggplot2)

corr <- cor(plotdata$y1, plotdata$y2)

# scatter plot and coefficient
ggplot(plotdata, aes(x = y1, y = y2)) +
  geom_point(alpha = 0.5,color="deepskyblue3") +  # 
  # geom_smooth(method = "lm", se = TRUE,color="red") + 
  labs(title ="(c)" ,
       x=expression(Y[i][1]),
       y=expression(Y[i][2]))+
  theme_bw()+
  theme(
    plot.title = element_text(
      hjust = 0.5,  # 
      size = 14,    # 
      face = "bold" # 
    )
  )

#expression(paste("coefficient of " ,Y[i][1], " and ", Y[i][2]))
#geom_text(
#x = max(plotdata$y1) * 0.8, 
#y = max(plotdata$y2) * 0.9,
#label = paste("corr =", round(corr, 2)),  
#size = 5, color = "black"
#) +
#########affect function  
Affect_X<-function(theta,x1,x2,L,m,dth,pth){
  #theta=mpcp_theta_sc;x=seq(min(X[,2]),max(X[,2]),0.001)
  #L=2;m=3;dth=2;pth=2
  nu=theta[1:(2*L)]
  beta=theta[(2*L+1):(2*L+m*2)]
  nui=nu[((dth-1)*L+1):((dth-1)*L+L)]
  betai=beta[((dth-1)*m+1):(dth*m)]
  n=length(x1)
  x=cbind(rep(1,n),x1,x2)
  
  lami=Sc(x%*%betai)
  
  ssum1=2*nui[1]*lami^2+lami*nui[1]^2+4*lami*nui[1]*nui[2]+4*nui[2]^2
  ssum2=lami^2+nui[1]^2*lami+2*nui[2]^2
  g=lami+ssum1/ssum2/d
  
  ssum3=2*lami^2*nui[1]^3+8*lami*nui[1]*nui[2]^2+8*nui[1]*nui[2]^3-lami^2*nui[1]^2-4*lami^2*nui[1]*nui[2]-8*lami*nui[2]^2-2*nui[1]^2*nui[2]^2
  ssum4=(lami^2+nui[1]^2*lami+2*nui[2]^2)^2
  pro1=ssum3/ssum4
  pro2=d_Sc(x%*%betai)
  betaip=betai[pth]
  dg=(1+pro1/2)*pro2*betaip
  return(list(g=g,dg=dg))
}
X2_test=seq(min(X[,2]),max(X[,2]),0.001)
X3_fix=quantile(X[,3], probs = c(0.25, 0.5, 0.75))
#L,m,dth,pth
Y1X2_affect1=Affect_X(mpcp_theta_sc,X2_test,rep(X3_fix[1],length(X2_test)),2,3,1,2)
Y1X2_affect2=Affect_X(mpcp_theta_sc,X2_test,rep(X3_fix[2],length(X2_test)),2,3,1,2)
Y1X2_affect3=Affect_X(mpcp_theta_sc,X2_test,rep(X3_fix[3],length(X2_test)),2,3,1,2)

Y2X2_affect1=Affect_X(mpcp_theta_sc,X2_test,rep(X3_fix[1],length(X2_test)),2,3,2,2)
Y2X2_affect2=Affect_X(mpcp_theta_sc,X2_test,rep(X3_fix[2],length(X2_test)),2,3,2,2)
Y2X2_affect3=Affect_X(mpcp_theta_sc,X2_test,rep(X3_fix[3],length(X2_test)),2,3,2,2)

par(mfrow = c(1, 2),mar=c(4,5,2,1),
    oma = c(0, 0, 2, 0))  # 
X2.lab=as.character(round(seq(min(X[,2]),max(X[,2]),by=1),3))
plot(Y1X2_affect1$g,type="l",lwd=2,xaxt="n",
     xlab=expression(X[i2]~(PM["10"])),
     ylab=expression(G[1](paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y1X2_affect1$g),max(Y1X2_affect3$g)+1),
     #xlim=c(min(c(X2_test,X3_fix))-2,max(c(X2_test,X3_fix))+15),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X2_test),by=1000),labels = X2.lab)
lines(Y1X2_affect2$g,lty=2,lwd=2)
lines(Y1X2_affect3$g,lty=3,lwd=2)
legend("topright",c(expression(paste("25% quantile of ", X[i3])),
                   expression(paste("50% quantile of ", X[i3])),
                   expression(paste("75% quantile of ", X[i3]))),
       col=c("black","black","black"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)

plot(Y1X2_affect1$dg,type="l",lwd=2,col="deepskyblue3",
     xlab=expression(X[i2]~(PM["10"])),xaxt="n",
     ylab=expression(G[1]^"*"~(paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y1X2_affect3$dg),max(Y1X2_affect1$dg)+0.01),
     #xlim=c(min(c(X2_test,X3_fix))-1,max(c(X2_test,X3_fix))+15),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X2_test),by=1000),labels = X2.lab)
lines(Y1X2_affect2$dg,col="deepskyblue3",lty=2,lwd=2)
lines(Y1X2_affect3$dg,col="deepskyblue3",lty=3,lwd=2)
legend("topright",c(expression(paste("25% quantile of ", X[i3])),
                    expression(paste("50% quantile of ", X[i3])),
                    expression(paste("75% quantile of ", X[i3]))),
       col=c("deepskyblue3","deepskyblue3","deepskyblue3"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)

mtext(
  text = expression(paste("Panel A: the effect of ", X[i][2]," on ", Y[i][1])),  # 
  side = 3,  # location（1=bottom，2=left，3=top，4=right）
  line = 0.0001,  
  outer = TRUE,  
  cex = 1.2 # 
)

#text(2,1.14,"(a1)")
par(mfrow = c(1, 2),mar=c(4,5,2,1),
    oma = c(0, 0, 2, 0))  # 
plot(Y2X2_affect1$g,type="l",lwd=2,
     xlab=expression(X[i2]~(PM["10"])),xaxt="n",
     ylab=expression(G[2](paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y2X2_affect1$g),max(Y2X2_affect3$g)+1.5),
     #xlim=c(min(c(X2_test,X3_fix))-1,max(c(X2_test,X3_fix))+15),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X2_test),by=1000),labels = X2.lab)

lines(Y2X2_affect2$g,lty=2,lwd=2)
lines(Y2X2_affect3$g,lty=3,lwd=2)
legend("topright",c(expression(paste("25% quantile of ", X[i3])),
                    expression(paste("50% quantile of ", X[i3])),
                    expression(paste("75% quantile of ", X[i3]))),
       col=c("black","black","black"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)

plot(Y2X2_affect1$dg,type="l",lwd=2,col="deepskyblue3",
     xlab=expression(X[i2]~(PM["10"])),xaxt="n",
     ylab=expression(G[2]^"*"~(paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y2X2_affect1$dg),max(Y2X2_affect3$dg)+0.01),
     #xlim=c(min(c(X2_test,X3_fix))-1,max(c(X2_test,X3_fix))+15),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X2_test),by=1000),labels = X2.lab)

lines(Y2X2_affect2$dg,col="deepskyblue3",lty=2,lwd=2)
lines(Y2X2_affect3$dg,col="deepskyblue3",lty=3,lwd=2)
legend("topright",c(expression(paste("25% quantile of ", X[i3])),
                    expression(paste("50% quantile of ", X[i3])),
                    expression(paste("75% quantile of ", X[i3]))),
       col=c("deepskyblue3","deepskyblue3","deepskyblue3"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)

mtext(
  text = expression(paste("Panel B: the effect of ", X[i][2]," on ", Y[i][2])),  # 总标题文本
  side = 3,  # 
  line = 0.0001,  #
  outer = TRUE,  # 
  cex = 1.2 # 
)


X3_test=seq(min(X[,3]),max(X[,3]),0.001)
X2_fix=quantile(X[,2], probs = c(0.25, 0.5, 0.75))
Y1X3_affect1=Affect_X(mpcp_theta_sc,X2_fix[1],X3_test,2,3,1,2)
Y1X3_affect2=Affect_X(mpcp_theta_sc,X2_fix[2],X3_test,2,3,1,2)
Y1X3_affect3=Affect_X(mpcp_theta_sc,X2_fix[3],X3_test,2,3,1,2)

Y2X3_affect1=Affect_X(mpcp_theta_sc,X2_fix[1],X3_test,2,3,2,2)
Y2X3_affect2=Affect_X(mpcp_theta_sc,X2_fix[2],X3_test,2,3,2,2)
Y2X3_affect3=Affect_X(mpcp_theta_sc,X2_fix[3],X3_test,2,3,2,2)



par(mfrow = c(1, 2),mar=c(4,5,2,1),
    oma = c(0, 0, 2, 0))  # 
X3.lab=as.character(round(seq(min(X[,3]),max(X[,3]),by=1),3))
plot(Y1X3_affect1$g,type="l",lwd=2,
     xlab=expression(X[i3]~(PM[2.5])),xaxt="n",
     ylab=expression(G[1](paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y1X3_affect3$g),max(Y1X3_affect1$g)+1),
     #xlim=c(min(c(X3_test,X2_fix))-1,max(c(X3_test,X2_fix))+10),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X3_test),by=1000),labels = X3.lab)

lines(Y1X3_affect2$g,lty=2,lwd=2)
lines(Y1X3_affect3$g,lty=3,lwd=2)
legend("topright",c(expression(paste("25% quantile of ", X[i2])),
                    expression(paste("50% quantile of ", X[i2])),
                    expression(paste("75% quantile of ", X[i2]))),
       col=c("black","black","black"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)



#text(2,1.14,"(a1)")
plot(Y1X3_affect1$dg,type="l",lwd=2,col="deepskyblue3",
     xlab=expression(X[i3]~(PM[2.5])),xaxt="n",
     ylab=expression(G[1]^"**"~(paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y1X3_affect1$dg),max(Y1X3_affect3$dg)+0.005),
     #xlim=c(min(c(X3_test,X2_fix))-1,max(c(X3_test,X2_fix))+10),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X3_test),by=1000),labels = X3.lab)

lines(Y1X3_affect2$dg,col="deepskyblue3",lty=2,lwd=2)
lines(Y1X3_affect3$dg,col="deepskyblue3",lty=3,lwd=2)
legend("topright",c(expression(paste("25% quantile of ", X[i2])),
                    expression(paste("50% quantile of ", X[i2])),
                    expression(paste("75% quantile of ", X[i2]))),
       col=c("deepskyblue3","deepskyblue3","deepskyblue3"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)
mtext(
  text = expression(paste("Panel A: the effect of ", X[i3]," on ", Y[i][1])),  # 总标题文本
  side = 3,  
  line = 0.0001,  
  outer = TRUE,  
  cex = 1.2 # 
)
par(mfrow = c(1, 2),mar=c(4,5,2,1),
    oma = c(0, 0, 2, 0))  # 


plot(Y2X3_affect1$g,type="l",lwd=2,
     xlab=expression(X[i3]~(PM[2.5])),xaxt="n",
     ylab=expression(G[2](paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y2X3_affect1$g),max(Y2X3_affect3$g)+1),
     #xlim=c(min(c(X3_test,X2_fix))-1,max(c(X3_test,X2_fix))+10),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X3_test),by=1000),labels = X3.lab)

lines(Y2X3_affect2$g,lty=2,lwd=2)
lines(Y2X3_affect3$g,lty=3,lwd=2)
legend("topright",c(expression(paste("25% quantile of ", X[i2])),
                    expression(paste("50% quantile of ", X[i2])),
                    expression(paste("75% quantile of ", X[i2]))),
       col=c("black","black","black"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)

plot(Y2X3_affect1$dg,type="l",lwd=2,col="deepskyblue3",
     xlab=expression(X[i3]~(PM[2.5])),xaxt="n",
     ylab=expression(G[2]^"**"~(paste(X[i2],", ",X[i3]))),
     ylim=c(min(Y2X3_affect1$dg),max(Y2X3_affect3$dg)+0.008),
     #xlim=c(min(c(X3_test,X2_fix))-1,max(c(X3_test,X2_fix))+10),
     cex.axis=1.2,cex.lab=1.2)
axis(1,at=seq(1,length(X3_test),by=1000),labels = X3.lab)

lines(Y2X3_affect2$dg,lty=2,lwd=2,col="deepskyblue3")
lines(Y2X3_affect3$dg,lty=3,lwd=2,col="deepskyblue3")
legend("topright",c(expression(paste("25% quantile of ", X[i2])),
                    expression(paste("50% quantile of ", X[i2])),
                    expression(paste("75% quantile of ", X[i2]))),
       col=c("deepskyblue3","deepskyblue3","deepskyblue3"),
       text.col=c("black","black","black"),
       lty=c(1,2,3),ncol=1,cex=1,lwd=2)
mtext(
  text = expression(paste("Panel B: the effect of ", X[i3]," on ", Y[i][2])),  # 总标题文本
  side = 3,  
  line = 0.0001,  
  outer = TRUE,  
  cex = 1.2 # 
)
