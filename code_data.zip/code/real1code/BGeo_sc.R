Sc<-function(x,c=1){
  return(c*log(1+exp(x/c)))
}
KG <- function(theta, tol = 1e-10, max_iter = 100000) {
  q1=theta[1];q2=theta[2];q3=theta[3]
  if (q3 <= 0 || q3 > 1) stop("q3 must be in (0, 1]")
  
  # 处理 q3 = 1 的情况 (独立情形)
  if (q3 == 1) {
    return((1 - q1) * (1 - q2))
  }
  
  invK <- 0
  x <- 0
  converged <- FALSE
  
  while (x <= max_iter) {
    term <- q1^x / (1 - q2 * q3^x)
    invK <- invK + term
    
    # 检查收敛性
    if (term < tol) {
      converged <- TRUE
      break
    }
    x <- x + 1
  }
  
  if (!converged) warning("Normalizing constant did not converge within max_iter.")
  return(1 / invK)
  
}

bgeo_pmf_sc<-function(q1,q2,q3,k,tol = 1e-10, max_iter = 100000){
  x=k[1];y=k[2]
  #q1=theta[1];q2=theta[2];q3=theta[3]
  theta=c(q1,q2,q3)
  if (any(x < 0) || any(y < 0)) stop("x and y must be non-negative integers")
  if (any(x != floor(x)) || any(y != floor(y))) stop("x and y must be integers")
  
  # 计算归一化常数
  KG <- KG(theta, tol, max_iter)
  
  # 计算概率
  prob <- KG * (q1^x) * (q2^y) * (q3^(x * y))
  return(prob)
}
bgeo_Lik_sc<-function(theta,data,X){
  
  y=data
  N=dim(data)[2]
  m=dim(X)[2]
  beta1=theta[1:m];beta2=theta[(m+1):(2*m)]
  q3=theta[(2*m)+1]
  q1=Sc(X%*%beta1)
  q2=Sc(X%*%beta2)
  ell=rep(0,N)
  for(t in 1:N){
    ell[t]=bgeo_pmf_sc(q1[t],q2[t],q3,y[,t])
  }
  ell<-ell[!is.infinite(ell) & ell >= 0]
  ell1=log(ell)
  loglik=-sum(ell1[!is.na(ell1)])
  return(loglik)
}