Product1_exp<-function(theta,k,xj){
  p=length(k)
  m=length(xj)
  beta=theta[1:(p*m)]
  phi=theta[p*m+1]
  pro1=1
  for(j in 1:p){
    betaj=beta[((j-1)*m+1):(j*m)];
    lambdaj=exp(xj%*%betaj)
    pro1=pro1*(lambdaj^k[j])
  }
  return(pro1)
}

Product2_exp<-function(theta,k){
  p=length(k)
  pro2=1
  for(j in 1:p){
    pro2=pro2*gamma(k[j]+1)
  }
  return(pro2)
}

mnb_pmf_exp<-function(theta,k,xj){
  p=length(k)
  m=length(xj)
  beta=theta[1:(p*m)]
  phi=theta[p*m+1]
  a=gamma(1/phi+sum(k))/(gamma(1/phi)*Product2_exp(theta,k))
  b=Product1_exp(theta,k,xj)*(phi^(-1/phi))
  lambda=rep(0,p)
  for(j in 1:p){
    betaj=beta[((j-1)*m+1):(j*m)];
    lambda[j]=exp(xj%*%betaj)
  }
  c=(1/phi+sum(lambda))^(-(1/phi+sum(k)))
  pmf=a*b*c
  return(pmf)
}

mnb_Lik_exp<-function(theta,data,X){
  #theta=theta_0
  y=data
  p=dim(y)[1];
  N=dim(y)[2];
  m=dim(X)[2]
  ell=rep(0,N)
  for(t in 1:N){
    ell[t]=mnb_pmf_exp(theta,y[,t],X[t,])
  }
  ell<-ell[!is.infinite(ell) & ell >= 0]
  ell1=log(ell)
  loglik=-sum(ell1[!is.na(ell1)])
  return(loglik)
} 

mnb_DGP_exp<-function(theta,p,N){
  beta=theta[1:(p*m)]
  phi=theta[p*m+1]
  library(MASS)
  X=cbind(rep(1,N),mvrnorm(N,rep(0.5,m-1),diag(0.25,m-1)))
  
  omega=rgamma(1,1/phi,1/phi)
  y=matrix(0,p,N)
  for (j in 1:p){
    betaj=beta[((j-1)*m+1):(j*m)];
    lambda=exp(X%*%betaj)
    y[j,]=rpois(N,omega*lambda)
  }
  return(y)
}


