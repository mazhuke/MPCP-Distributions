
bcp_pmf<-function(theta,k){
  x=k[1];y=k[2];
  lambda1=theta[1];lambda2=theta[2]
  phi=theta[3]
  a=(lambda1^x)*(lambda2^y)/(factorial(x)*factorial(y))
  b=-lambda1*(1+y*(exp(phi)-1))
  c=-lambda2*exp(-lambda1*(exp(phi)-1)+phi*x)
  d=phi*x*y
  pmf=a*exp(b+c+d)
  return(pmf)
}

bcp_Lik<-function(theta,data){
  #theta=theta_0
  y=data
  N=dim(y)[2];
  ell=rep(0,N)
  for(t in 1:N){
    ell[t]=bcp_pmf(theta,y[,t])
  }
  ell[ell<=0]=1
  return(-sum(log(ell)))
} 

bcp_DGP<-function(theta,N){
  #theta=c(2,2,1)
  lambda1=theta[1];lambda2=theta[2]
  phi=theta[3]
  
  Z1=rpois(N,lambda1)
  mu2=lambda2*exp(-lambda1*(exp(phi)-1))
  Z2=rpois(N,mu2*exp(phi*Z1))
  y=rbind(Z1,Z2)
  return(y)
}


