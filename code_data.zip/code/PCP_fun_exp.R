################## PCP distribution function###############################
######################require packages
package_list <- c("Rcpp", "numDeriv", "gtools","pscl","tidyverse")

# 
for (package_name in package_list) {
  if (!require(package_name, character.only = TRUE)) {
    install.packages(package_name)
    library(package_name, character.only = TRUE)
  }
}


library(broom)            # conclude statistical modelling results
library(COMPoissonReg)    # CMP
library(dplyr)            # dataframe processing
library(ggplot2)          # plot
library(gtools)
library(modelr)
library(MASS)             # glm.nb
library(numDeriv)         # grad
library(pscl)             # zeroinfl
library(progress)         # progress bar
library(Rcpp)             # use c++ in R
library(readxl)
library(sandwich) 
library(tidyverse)
library(foreach)          # parallel
library(doParallel)
##################Poisson-Charlier polynomials (2.3)
##(x)n is the falling factorial
falling <- function(x,n){
  return(choose(x,n)*factorial(n))
}   

##(2.3)
PCP <- function(n,k,lambda){
  
  sum1=0
  for (i in 0:n) {
    sum1 <-sum1+ choose(n,i)*(-1)^(n-i)*lambda^(-i)*falling(k,i)
  }
  return(sum1) ###
}  
############PCP probability mass function (2.5)
PCP_sum<-function(k,lambda,nu,L){
  #k=0
  sum2=0
  nu_n=c(1,nu)
  for(n in 0:L){
    sum2=sum2+nu_n[n+1]*PCP(n,k,lambda)
  }
  return(sum2)
}
#dn(lambda)
dn <- function(L,lambda){
  if (L == 0) {
    result <- 1
  } else {
    result <- rep(0, (L+1))
    for (n in 0:L) {
      result[n+1] <- factorial(n)*lambda^(-n)
    }
  }
  return(sqrt(result)) #c(d0(lambda),...,dL(lambda))
}
#(2.5)
PCP_pmf<-function(k,lambda,nu,L){
  #k=0
  pk =  dpois(k,lambda)
  nu_n = c(1,nu)
  u=nu_n*dn(L,lambda)
  qk=pk*PCP_sum(k,lambda,nu,L)^2/c(t(u)%*%(u))
  return(qk)
}
######################loglikehoood function (2.11)
pcp_Lik_exp <- function(theta,data,covariate,L,N){
  y=data
  nu = theta[1:L]
  X=covariate
  m=dim(X)[2]
  beta=theta[(L+1):(L+m)]
  lambda=exp(X%*%beta)
  
  ell=rep(0,N)
  for(j in 1:N){
    ell[j]=PCP_pmf(y[j],lambda[j],nu,L)
  }
  return(-sum(log(ell)))
}   # vector data, scalar lambda, vector nu(length=L)
################The first estimator is to estimate matrix Sigma
##d(lj)/d(nu)
Lik_dnu<-function(yj,xj,theta,L){
  #theta=theta_0;yj=y[1]
  nu = theta[1:L]
  m=length(xj)
  beta=theta[(L+1):(L+m)]
  lambdaj=exp(t(xj)%*%beta)
  
  nu_n = c(1,nu)
  u=nu_n*dn(L,lambdaj)
  dnu=rep(0,L)
  for(i in 1:L){
    #i=1
    dnu[i]=-2*factorial(i)*nu[i]*lambdaj^(-i)/c(t(u)%*%(u))+
      2*PCP(i,yj,lambdaj)/PCP_sum(yj,lambdaj,nu,L)
  }
  return(dnu)#c(dnu1,..,dnuL)
}
##d(lj)/d(lambda)
Lik_dlambda<-function(yj,xj,theta,L){
  #yj=y[1]
  nu = theta[1:L]
  m=length(xj)
  beta=theta[(L+1):(L+m)]
  lambdaj=exp(t(xj)%*%beta)
  
  nu_n = c(1,nu)
  u=nu_n*dn(L,lambdaj)
  s1=0;s2=0
  for(n in 1:L){
    s1=s1+factorial(n)*n*nu[n]^2*lambdaj^(-n-1);
    s2=s2+n*nu[n]*PCP(n-1,yj-1,lambdaj);
  }
  
  dlambda= yj/lambdaj-1+s1/c(t(u)%*%(u))-
    (2*yj*s2)/(lambdaj^2*PCP_sum(yj,lambdaj,nu,L))
  return(dlambda)
}
Lik_dbeta<-function(yj,xj,theta,L){
  #yj=y[1];xj=X[1,]
  m=length(xj)
  beta=theta[(L+1):(L+m)] 
  dbeta=c(Lik_dlambda(yj,xj,theta,L)*exp(t(xj)%*%beta))*(xj)
  return(dbeta)
}
##d(lj)/d(psi)
Lik_dpsi<-function(yj,xj,theta,L){
  return(c(Lik_dnu(yj,xj,theta,L),Lik_dbeta(yj,xj,theta,L)))
}
######The first estimator is to estimate matrix Σ
PCP_Fisher_exp<-function(theta,data,covariate,L,N){
  #theta=theta_0
  y=data
  X=covariate
  m=dim(X)[2]
  I1=matrix(0,(L+m),(L+m))
  for(j in 1:N){
    I1=I1+Lik_dpsi(y[j],X[j,],theta,L)%*%t(Lik_dpsi(y[j],X[j,],theta,L))
  }
  return(I1/N)
}
######################DGP: data generate process
PCP_data_exp<- function(nu,beta,L,N){
  y0 <- rep(0, N)
  #nu=nu_0;lambda=lam_0
  x0t=rep(1,N)
  x1t=runif(N,0,1); #x1~U[0,1]
  x2t=rnorm(N,0,1);#x2~N(0,1)
  x3t=sample(c(-1,0,1), size=N,replace = TRUE)
  X=cbind(x0t,x1t,x2t,x3t)
  lambda=exp(X%*%beta)
  for (i in 1:N) {
    u <- runif(1)
    a <- 0
    f <- PCP_pmf(a,lambda[i],nu,L)
    while (u >= f) {
      a <- a + 1
      f <- f + PCP_pmf(a,lambda[i],nu,L)
    }
    y0[i] <- a
  }
  data=y0;
  return(list(data=data,X=X))
}

