################## Multivariate PCP  distribution###############################
######################require packages
library(broom)            # conclude statistical modelling results
library(COMPoissonReg)    # CMP
library(dplyr)            # dataframe processing
library(ggplot2)          # plot
library(gtools)
library(modelr)
library(MASS)             # glm.nb
library(numDeriv)
library(pscl)             # zeroinfl
library(progress)         # progress bar
library(Rcpp)             # use c++ in R
library(readxl)
library(sandwich) 
library(tidyverse)
library(foreach)          # parallel
library(doParallel)
##################Poisson-Charlier polynomials (2.3)
##(x)n is the falling factorial
falling <- function(x,n){
  return(choose(x,n)*factorial(n))
}   

##(2.3)
PCP <- function(n,k,lambda){
  
  sum1=0
  for (i in 0:n) {
    sum1 <-sum1+ choose(n,i)*(-1)^(n-i)*lambda^(-i)*falling(k,i)
  }
  return(sum1) ###
}  
############PCP probability mass function (6.1)
#sum_n^L vjnCn(k,lambda)
PCP_sum<-function(kj,lambda_j,nu_j,L){
  #k=0
  sum2=0
  
  for(n in 0:L){
    sum2=sum2+nu_j[n+1]*PCP(n,kj,lambda_j)
  }
  return(sum2)
}
#dn(lambda)
dn <- function(L,lambda_j){
  if (L == 0) {
    result <- 1
  } else {
    result <- rep(0, L)
    for (n in 1:L) {
      result[n] <- factorial(n)*lambda_j^(-n)
    }
  }
  result1=c(1,result)
  return(sqrt(result1)) #c(d0(lambda),...,dL(lambda))
}
#(6.1)
MPCP_pmf<-function(k,lambda,nu,L){
  #nu:d*L-dimensional
  #k=c(0,0);lambda=1;nu=c(1,3)
  d=length(k) ##d-dimensional 
  product1=1;sum1=0
  for(j in 1:d){
    pkj =  dpois(k[j],lambda[j])
    product1=product1*pkj 
    nu_j = c(1,nu[((j-1)*L+1):(j*L)]) #L+1-dimensional
    uj=nu_j*dn(L,lambda[j])
    sum1=sum1+PCP_sum(k[j],lambda[j],nu_j,L)^2/c(t(uj)%*%(uj))
  }
  qk=product1*sum1/d
  return(qk)
}
MPCP_marpmf<-function(kj,lambdaj,nuj,d,L){
  #nu:d*L-dimensional
  #k=c(0,0);lambda=1;nu=c(1,3)
  pkj =  dpois(kj,lambdaj)
  nu_j = c(1,nuj) #L+1-dimensional
  uj=nu_j*dn(L,lambdaj)
  wj=PCP_sum(kj,lambdaj,nu_j,L)^2/c(t(uj)%*%(uj))
  qkj=pkj*((d-1)/d+wj/d)
  return(qkj)
}
L <- 2
d<-2
#Panel A
lam_0=c(5,10);lambda1=lam_0[1];lambda2=lam_0[2];#lambda
nu_0=c(1,1,3,1);nu1=nu_0[1:2];nu2=nu_0[3:4];
Y1=0:20;Y2=0:20

ell1=rep(0,N);ell2=rep(0,N)
for(t in 1:N){
  ell1[t]=MPCP_marpmf(Y1[t],lambda1,nu1,d,L)
  ell2[t]=MPCP_marpmf(Y2[t],lambda2,nu2,d,L)
}
par(mfrow = c(1, 2),mar=c(4,5,2,1),
    oma = c(0, 0, 2, 0))  # 外层边距（给总标题留空间，单位：行数）
plot(ell1,type="o",pch=19,
     main ="",#expression(paste("Panel A: ", MPCP[2]," with ",d==2,": ",bold(psi)[1],"=(1,1,5)'")),
     xlab = expression(Y[1]),
     ylab = "",
     las = 1)  # y轴标签水平显示)
plot(ell2,type="o",pch=19,
     main ="",#expression(paste("Panel A: ", MPCP[2]," with ",d==2,": ",bold(psi)[2],"=(3,1,10)'")),
     xlab = expression(Y[2]),
     ylab = "",
     las = 1)  # y轴标签水平显示)
mtext(
  text = expression(paste("Panel A: ", MPCP[2]," with ",d==2,", ",bold(psi)[1],"=(1,1,5)'",", and ",bold(psi)[2],"=(3,1,10)'")),  # 总标题文本
  side = 3,  # 位置：顶部（1=下，2=左，3=上，4=右）
  line = 0.0001,  # 距离顶部的行数（配合oma调整）
  outer = TRUE,  # 跨越整个画布（而非单个子图）
  cex = 1.2 # 字体大小
)
#Panel B
lam_0=c(10,10);lambda1=lam_0[1];lambda2=lam_0[2];#lambda
nu_0=c(5,-25,5,0);nu1=nu_0[1:2];nu2=nu_0[3:4];
Y1=0:20;Y2=0:20

ell1=rep(0,N);ell2=rep(0,N)
for(t in 1:N){
  ell1[t]=MPCP_marpmf(Y1[t],lambda1,nu1,d,L)
  ell2[t]=MPCP_marpmf(Y2[t],lambda2,nu2,d,L)
}
par(mar=c(4,5,2,1))
plot(ell1,type="o",pch=19,
     main ="",
     xlab = expression(Y[1]),
     ylab = "",
     las = 1)  # y轴标签水平显示)
plot(ell2,type="o",pch=19,
     main ="",
     xlab = expression(Y[2]),
     ylab = "",
     las = 1)  # y轴标签水平显示)
mtext(
  text = expression(paste("Panel B: ", MPCP[2]," with ",d==2,", ",bold(psi)[1],"=(5,-25,10)'",", and ",bold(psi)[2],"=(5,0,10)'")),  # 总标题文本
  side = 3,  # 位置：顶部（1=下，2=左，3=上，4=右）
  line = 0.0001,  # 距离顶部的行数（配合oma调整）
  outer = TRUE,  # 跨越整个画布（而非单个子图）
  cex = 1.2 # 字体大小
)
#####Panel C

lam_0=c(5,10);lambda1=lam_0[1];lambda2=lam_0[2];#lambda
nu_0=c(5,10,5,-15);nu1=nu_0[1:2];nu2=nu_0[3:4];
Y1=0:20;Y2=0:20

ell1=rep(0,N);ell2=rep(0,N)
for(t in 1:N){
  ell1[t]=MPCP_marpmf(Y1[t],lambda1,nu1,d,L)
  ell2[t]=MPCP_marpmf(Y2[t],lambda2,nu2,d,L)
}
par(mar=c(4,5,2,1))
plot(ell1,type="o",pch=19,
     main ="",
     xlab = expression(Y[1]),
     ylab = "",
     las = 1)  # y轴标签水平显示)
plot(ell2,type="o",pch=19,
     main ="",
     xlab = expression(Y[2]),
     ylab = "",
     las = 1)  # y轴标签水平显示)
mtext(
  text = expression(paste("Panel C: ", MPCP[2]," with ",d==2,", ",bold(psi)[1],"=(5,10,5)'",", and ",bold(psi)[2],"=(5,-15,10)'")),  # 总标题文本
  side = 3,  # 位置：顶部（1=下，2=左，3=上，4=右）
  line = 0.0001,  # 距离顶部的行数（配合oma调整）
  outer = TRUE,  # 跨越整个画布（而非单个子图）
  cex = 1.2 # 字体大小
)