###########digital-diet-healthy#################
###https://www.kaggle.com/datasets/khushikyad001/impact-of-screen-time-on-mental-health
#x1:daily_screen_time_hours
#x2:sleep_quality
#x3:physical_activity_hours_per_week
#x4:log(caffeine_intake_mg_per_day)
#x5:eats_healthy
#x6:mindfulness_minutes_per_day
######
#y1:mood_rating
#y2:stress_level
#y3:weekly_anxiety_score
#y4:weekly_depression_score
###################################################
#read data
setwd("/Users/xunuo/Desktop/多元回归(模拟)/20250716/code_check/real")
all_data=read.csv("digital_habits_vs_mental_health.csv")
#response
set.seed(123)  # 设置随机数种子，保证结果可复现
index <- sample(x = 1:100000, size = 10000, replace = FALSE)
y1=all_data$stress_level[index]
y2=all_data$mood_score[index]
#covariate
x1=all_data$hours_on_TikTok[index]
x2=all_data$sleep_hours[index]


##############without covariate#######
source("MPCP_fun.R")
N=length(y1)
d=2
L=1

y=rbind(y1,y2)

freq_table <- table(y1)
barplot(freq_table, 
        main = "序列取值频数分布", 
        xlab = "取值", 
        ylab = "频数",
        col = "skyblue",  # 柱子颜色
        border = NA)
freq_table <- table(y2*10)
barplot(freq_table, 
        main = "序列取值频数分布", 
        xlab = "取值", 
        ylab = "频数",
        col = "skyblue",  # 柱子颜色
        border = NA)



theta_00 = c(rep(1,d*L),1,1)

mpcp_fit <- optim(par = theta_00, fn=mpcp_Lik, 
                  method="BFGS",hessian = TRUE,
                  data=y,L=L,N=N,d=d)
mpcp_lik <- mpcp_fit$value
mpcp_theta <- mpcp_fit$par 
H <- mpcp_fit$hessian

mpcp_Sigma2 <- ginv(H)*N
solve_I<- try(MPCP_Fisher(mpcp_theta,y,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I)){ 
  print("try error in Fisher")
  next
}else{ 
  mpcp_I =solve_I
  
}
mpcp_Sigma1 <- solve(mpcp_I)
mpcp_Sigma3 <-(mpcp_Sigma2)%*%(mpcp_I)%*%(mpcp_Sigma2)
mpcp_std<- sqrt(diag(mpcp_Sigma3)/N)


AIC=2*mpcp_lik+2*(d*L+d)
BIC=2*mpcp_lik+(d*L+d)*log(N)
logL=mpcp_lik
round(c(logL,AIC,BIC),4)
t.statistics=round(mpcp_theta/mpcp_std,4)
p=2*(1-pnorm(abs(t.statistics))) 
round(p,4)
out<-rbind(round(mpcp_theta,4),
           round(mpcp_std,4),
           round(t.statistics,4),
           round(p,4))
################regression model (softplus)

source("MPCP_fun_sc.R")
#covariate
X=cbind(rep(1,N),x1)
m=dim(X)[2]
theta_01 = c(5,5,rep(0.1,d*m))
mpcp_fit_sc <- optim(par = theta_01, fn=mpcp_Lik_sc, 
                     method="BFGS",hessian = TRUE,
                     data=y,covariate=X,L=L,N=N,d=d)
mpcp_lik_sc <- mpcp_fit_sc$value
mpcp_theta_sc <- mpcp_fit_sc$par 
#H_sc <- mpcp_fit_sc$hessian
#mpcp_Sigma2_sc <- ginv(H_sc)*N
#pcp_bias <- pcp_theta-theta_0
solve_I_sc<- try(MPCP_Fisher_sc(mpcp_theta_sc,y,X,L,N,d),silent=T)      #cancle 
if(('NaN' %in% solve_I_sc)){ 
  print("try error in Fisher")
}else{ 
  mpcp_I_sc =solve_I_sc
  
}

mpcp_Sigma1_sc <- ginv(mpcp_I_sc)
#mpcp_Sigma3_sc <-(mpcp_Sigma2_sc)%*%(mpcp_I_sc)%*%(mpcp_Sigma2_sc)
mpcp_std_sc<-  sqrt(diag(mpcp_Sigma1_sc)/N)
#sqrt(diag(mpcp_Sigma3_sc)/N)
AIC_sc=2*mpcp_lik_sc+2*(d*L+m*d)
BIC_sc=2*mpcp_lik_sc+(d*L+m*d)*log(N)
logL_sc=mpcp_lik_sc
t.statistics_sc=round(mpcp_theta_sc/mpcp_std_sc,4)
p_sc=2*(1-pnorm(abs(t.statistics_sc))) 
round(p_sc,4)

sc_out<-rbind(round(mpcp_theta_sc,4),
              round(mpcp_std_sc,4),
              round(t.statistics_sc,4),
              round(p_sc,4))
round(c(logL_sc,AIC_sc,BIC_sc),4)