setwd("/Users/xunuo/Desktop/多元回归(模拟)/code_check")
source("PCP_fun.R")
#k <- 1
L <- 1
############################### Montecarlo
M <- 500 #Montecarlo replications
N <-100  #sample size

#PCP1 parameters
lam_0 = 1#lambda
#nu_0=c(1,3)
nu_0=c(1)


theta_0 = c(nu_0,lam_0) #psi=(lambda,nu1)

pcp_theta=matrix(0,L+1,M)
pcp_std1=matrix(0,L+1,M)->pcp_std2
pcp_std3=pcp_std1
pcp_LRT=rep(0,M)
time1 <- Sys.time()

for(i in 1:M){
  print(paste(i,"th Montecarlo at:",Sys.time()))
  ## Sample
  y <- PCP_data(nu_0,lam_0,L,N)

  
  # Poisson
  p_fit <- glm(y~1, family = poisson(link = "log"))
  p_est <- exp(coef(p_fit))
  p_lik <- c(logLik(p_fit))
  # PCP
  #library(optimx)
  init=theta_0#+runif(length(theta_0),-0.01,0.01)
  pcp_fit <- optim(par = init, fn=pcp_Lik,method="BFGS", hessian = TRUE,
                   data=y,L=L,N=N)
  pcp_lik <- -pcp_fit$value
  # pcp_fit <- optim(par = theta_0, fn=pcp_Lik, gr=pcp_grad, method="L-BFGS-B")
  pcp_theta[,i] <- pcp_fit$par
  #pcp_bias <- pcp_theta-theta_0
  H <- pcp_fit$hessian
  pcp_Sigma1 <- ginv(H)*N
  
  pcp_I <- PCP_Fisher(pcp_theta[,i],y,L,N)
  
  pcp_Sigma2 <- ginv(pcp_I)
  
  
  pcp_Sigma3 <-(pcp_Sigma1)%*%(pcp_I)%*%(pcp_Sigma1)
  
  pcp_std1[,i]<- sqrt(diag(pcp_Sigma2)/N)
  pcp_std2[,i]<- sqrt(diag(pcp_Sigma1)/N)
  pcp_std3[,i]<- sqrt(diag(pcp_Sigma3)/N)
  pcp_LRT[i] <- 2*(pcp_lik-p_lik)
}

time2 <- Sys.time()
print(time2-time1)


rowMeans(pcp_theta)-theta_0
round(apply(pcp_theta,1,sd),4)
round(rowMeans(pcp_std1),4)
round(rowMeans(pcp_std2),4)
round(rowMeans(pcp_std3),4)